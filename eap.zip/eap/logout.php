<?php
require_once('init.php');
$user->logout();
?>