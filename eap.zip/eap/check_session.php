<?php
require_once('init.php');
$custom_fun->send_mail("anam@pms.net.pk","e.connect.gulfam@gmail.com","Testing","Just testing");
?>