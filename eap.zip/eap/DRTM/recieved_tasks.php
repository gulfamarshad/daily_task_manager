<!DOCTYPE html>
<?php
require_once('../init.php');
if (!$user->is_login_TeamMember())
	{
      $custom_fun->redirect_page("".SITEURL."login/");
	}
else 
    {
     if(isset($_POST['done']))
       {
       	 $mafe = $_POST['completed'];
       	 foreach ($mafe as $key => $complete_value) {
	       	 /*Fetching existing member for concatination*/
			 $fetching_sql = "SELECT is_completed FROM ".PREFIX."tasks WHERE id=".$complete_value;
			 $fetched_complete = $db->fetch_single_row($fetching_sql)['is_completed'];
			 
			 if(empty($fetched_complete))
			   {
			   	$place_is_completed = $user->get_current_user()['id'];
			   }
			 else  
			   {
			   	$place_is_completed = $fetched_complete.",".$user->get_current_user()['id'];
			   }

       	 	 $update_query = "UPDATE ".PREFIX."tasks SET is_completed = '".$place_is_completed."' WHERE id = ".$complete_value; 
       	 	 $db->run_query($update_query);
       	 }
       
        	 //echo implode("_",$_POST['completed'] );
        	 foreach ($_POST['completed'] as $key => $value_ins) {
       	 	 $mafe_user = $user->get_current_user()['id'];
       	 	 $ins_query = "INSERT INTO ".PREFIX."complete_date (user_id,task_id,complete_date ) VALUES ('".$mafe_user."','".$value_ins."','".date('Y/m/d')."')";
	         $db->run_query($ins_query);
       	 	 }
       }
    	
    if(isset($_POST['send_cmts']))
      {
      	$comment_date = date('Y-m-d');
      	$user_id = $user->get_current_user() ['id'];
      	$cmts_data = array('comment_date'  => $comment_date, 
      					   'project_id'    => $_POST['project_id'] , 
      					   'task_id'       => $_POST['task_id'] , 
      					   'user_id'       => $user_id, 
      					   'task_comments' => mysql_real_escape_string($_POST['cmts']) 
      					  );
      	$db->insert_values($cmts_data,"task_comments");
      }

      if(isset($_POST['update_cmts']))
      {
      	$comment_date = date('Y-m-d');
      	$user_id = $user->get_current_user() ['id'];
      	$cmts_data = array('comment_date'  => $comment_date, 
      					   'project_id'    => $_POST['project_id'] , 
      					   'task_id'       => $_POST['task_id'] , 
      					   'user_id'       => $user_id, 
      					   'task_comments' => mysql_real_escape_string($_POST['cmts']) 
      					  );
      	$db->update_values($cmts_data,"task_comments",$_POST['up_id']);
      }

    }	
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Receive Tasks</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Tasks Assigned by Head of Department</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
						<!--Start contents form here-->
                  <div class="panel panel-blue">
					<div class="panel-heading dark-overlay"><svg class="glyph stroked clipboard-with-paper"><use xlink:href="#stroked-clipboard-with-paper"></use></svg>To-do List for <?php echo date('d-m-Y'); ?></div>
					<div class="panel-body">
						<form method="POST">
						<?php $custom_fun->show_todo(); ?>
					</div>
					<div class="panel-footer">
					<button type = "submit" class="btn btn-primary" id="btn-todo" name="done">Done</button>
					</form>
					</div>
				    </div>

				    <!--Start Popup model Edit-->
					      <?php
                  			$all_tasks = $db->fetch_all("SELECT * FROM ".PREFIX."tasks");
                  			foreach ($all_tasks as $key => $fetched_tasks) {
                          ?>
						<div id="popup_info<?php echo $fetched_tasks['id'];?>" class="modal-box">
						  <header> <div class="js-modal-close close"><img src="images/Button-Close-icon.png" alt="x"/></div>
						    <h3>Inform about Task</h3>
						  </header>
						  <div class="modal-body">
						    <p>
						      <!--Start Contents from here-->
							  <?php 
                              $fetch_details   = "SELECT * FROM ".PREFIX."task_comments WHERE task_id=".$fetched_tasks['id']." AND user_id=".$user->get_current_user()['id']." AND project_id = ".$fetched_tasks['concerned_project'].""; 
                              $fetched_details = $db->fetch_single_row($fetch_details);
                              if ($fetched_details['task_comments'] == "")
                                 {
                                 	$place_comments = "";
                                 	$place_btn = "send_cmts";
                                 }
                              if  ($fetched_details['task_comments'] != "")  
                                 {
                                 	$place_comments = $fetched_details['task_comments'];
                                 	$place_btn = "update_cmts";
                                 }
                              ?>
								<div class="row">
								   <div class="col-md-6">
								   <form method="POST"> 
								    <div class="form-group">
								    <label>Task Progress</label>
								    <textarea name="cmts" class="form-control" rows=3 required><?php echo $place_comments; ?></textarea>
								    <input type="hidden" name="project_id" value="<?php echo  $fetched_tasks['concerned_project'] ?>">
								    <input type="hidden" name="task_id" value="<?php echo  $fetched_tasks['id'] ?>">
								    <input type="hidden" name="up_id" value="<?php echo  $fetched_details['id'] ?>">
								    </div>
								  </div>
								</div>
						     <strong>Note:</strong> You can send your comments or about any complexity that you face in your task. 
						      <!--End Contents-->
						    </p>
						  </div>
						  <footer> 
                          <button type="submit" class="btn btn-primary" name="<?php echo $place_btn; ?>">Send</button>  
                          <!-- <div class="btn_pop js-modal-close">Close</div> -->  
						  </form>
						  </footer>
						</div>
						<?php
                          }
                        ?>

						<!--End Popup model Edit-->


						<!--End contents-->
			</div><!-- /.col-->
		</div><!-- /.row -->
		<div class="row">
			<div class="col-xs-6 col-md-4">
				<div class="alert bg-danger" role="alert">
					 TO DO
				</div>
				<div class="panel panel-default">					
					<div class="panel-body">						
						<div class="row">
                         <div class="col-lg-4">
                         <span class="input-group-addon">26 h</span>	
                        </div>
                         <div class="col-lg-8">
                        Refresh data content 
                        </div>
						</div>
					</div>
				</div>
               <div class="panel panel-default">					
					<div class="panel-body">
						<div class="row">
                         <div class="col-lg-4">
                         <span class="input-group-addon">26 h</span>	
                         </div>
                         <div class="col-lg-8">
                          Refresh data content 
                        </div>
						</div>
					</div>
				</div>
               <div class="panel panel-default">
					<div class="panel-body">
						<div class="row">
                         <div class="col-lg-4">
                         <span class="input-group-addon">26 h</span>	
                         </div>
                         <div class="col-lg-8">
                        Refresh data content 
                        </div>
						</div>
					</div>
				</div>
               <div class="panel panel-default">	
					<div class="panel-body">
						<div class="row">
                         <div class="col-lg-4">
                         <span class="input-group-addon">26 h</span>	
                         </div>
                         <div class="col-lg-8">
                        Refresh data content 
                        </div>
						</div>
					</div>
				</div>
               <div class="alert bg-danger" role="alert">
		        <svg class="glyph stroked plus sign" style="left: 125px;"><use xlink:href="#stroked-plus-sign"/></svg> 
				</div>
            </div>
            <div class="col-xs-6 col-md-4">
				<div class="alert bg-warning" role="alert">
					 IN PROGRESS
				</div>
					<div class="panel panel-default">
					<div class="panel-body">						
						<div class="row">
                         <div class="col-lg-4">                         	
                         <img src="image.jpg" style="height: 50px;">
                         </div>
                         <div class="col-lg-8">
                        Refresh data content
                        </div>
						</div>
					</div>
				</div>
				<div class="panel panel-default">					
					<div class="panel-body">
						<div class="row">
                         <div class="col-lg-4">
                         <img src="image.jpg" style="height: 50px;">
                          </div>
                         <div class="col-lg-8">
                        Refresh data content
                        </div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-4">
				<div class="alert bg-success" role="alert">
		                      DONE
				</div>
				<div class="panel panel-default">					
					<div class="panel-body">
						<div class="row">
                         <div class="col-lg-4"> 	
                         <img src="image.jpg" style="height: 50px;">
                         </div>
                         <div class="col-lg-8">
                        Refresh data content
                        </div>
						</div>
					</div>
				</div>
				<div class="panel panel-default">					
					<div class="panel-body">						
						<div class="row">
                         <div class="col-lg-4">                         	
                         <img src="image.jpg" style="height: 50px;">
                         </div>
                         <div class="col-lg-8">
                        Refresh data content
                        </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <!--End scripts-->
</body>

</html>
