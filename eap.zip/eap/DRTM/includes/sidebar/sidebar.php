	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<div class="circle"></div>
		<ul class="nav menu">
			<li class="active"><a href="<?php echo SITEURL."DRTM/"?>"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
		    <li class="parent ">
				<a href="<?php echo SITEURL."DRTM/change_password/"?>">
					<span data-toggle="collapse" href="#sub-item-3"><span class="glyphicon glyphicon-cog"></span> Account Settings </span>
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li>
						<a class="" href="<?php echo SITEURL."DRTM/profile/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Profile Settings
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRTM/change_password/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Change Password 
						</a>
					</li>
				</ul>
			</li>

			<li class="parent ">
				<a href="<?php echo SITEURL."DRTM/recieved_tasks/"?>">
					<span data-toggle="collapse" href="#sub-item-4"><span class="glyphicon glyphicon-list-alt"></span> My Tasks </span>
				</a>
				<ul class="children collapse" id="sub-item-4">
					<li>
						<a class="" href="<?php echo SITEURL."DRTM/recieved_tasks/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> My todo List
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRTM/task_history/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> My task History 
						</a>
					</li>
				</ul>
			</li>
			<li role="presentation" class="divider"></li>
		</ul>
	</div><!--/.sidebar-->