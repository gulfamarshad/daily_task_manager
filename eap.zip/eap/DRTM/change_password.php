<!DOCTYPE html>
<?php
require_once('../init.php');
if (!$user->is_login_TeamMember())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

else
{
  if(isset($_POST['done_pass']))
  {
    if ($_POST['new_pass'] !== $_POST['retype_new_pass'] )
	     {
	     	echo '<div class="isa_error" align="center">
            <strong>Error!</strong> New password retype not matching. Please try again.  
	     	</div>';
	     }
	else
	    {
	    $old_pass = $_POST['old_pass'];
	    $new_pass = $_POST['new_pass'];
	    $user->change_password($old_pass,$new_pass);
	    }
  }
}
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Change Password</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Change Password</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Change your old password</div>
					<div class="panel-body">
						<!--Start contents form here-->
                          <form class="" id="commentForm" method="post" action="" enctype="multipart/form-data">
                                <div class="row">
	                                <div class="col-md-6"> 
		                                 <div class="form-group">
		                                    <label for="old_pass" class="">Old Password (required)</label>
		                                    <div class="controls">
		                                        <input class="form-control" id="old_pass" name="old_pass" minlength="2" type="password" required />
		                                    </div>
		                                </div>
		                                
		                                <div class="form-group">
		                                    <label for="new_pass" class="">New Password </label>
		                                    <div class="form-group">
		                                        <input class="form-control" id="new_pass" name="new_pass" minlength="2" type="password" />
		                                    </div>
		                                </div>

		                                <div class="form-group">
		                                    <label for="new_pass" class="">Retype New Password </label>
		                                    <div class="form-group">
		                                        <input class="form-control" id="retype_new_pass" name="retype_new_pass" minlength="2" type="password" />
		                                    </div>
		                                </div>
		                                
		                                <div class=""> 
		                                    <button class="btn btn-primary" type="submit" name="done_pass" value="">Save</button>
		                                    <button class="btn" type="button">Cancel</button>
		                                </div>
                                    </div>
                               </div>
                            </form>
						<!--End contents-->
						
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <!--End scripts-->
</body>

</html>
