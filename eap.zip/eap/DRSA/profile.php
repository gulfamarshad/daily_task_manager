<!DOCTYPE html>
<?php
require_once('../init.php');

if (!$user->is_login_admin())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}
 $id = $user->get_current_user()['id'];
 $fetch_data_sql = "SELECT * FROM ".PREFIX."users WHERE id=".$id; 
 $result_fetch = $db->fetch_single_row($fetch_data_sql);
 
 $f_first_name     = $result_fetch['first_name'];
 $f_last_name      = $result_fetch['last_name'];
 $f_access_level   = $result_fetch['level_access'];
 $f_active         = $result_fetch['active'];
 $f_dial_code      = $result_fetch['dialing_code'];
 $f_phone_no       = $result_fetch['phone'];
 $f_email          = $result_fetch['email'];
 $f_country        = $result_fetch['country'];
 $f_city           = $result_fetch['city'];
 $btn              = "Update";
 $pw_text_box      = "";
 
 if (isset($_POST['reg']))
   {

  $user->update_profile_info();

   }
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lumino - Forms</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Profile</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Profile Settings</div>
					<div class="panel-body">
						<!--Start contents form here-->
						<!-- BEGIN FORM-->
                           <div class="row">
                           	 <div class="col-md-6">
                            <form class="" id="commentForm" method="post" action="" enctype="multipart/form-data">
                                 <div class="form-group ">
                                    <label for="f_name" class="control-label">First Name </label>
                                    <div class="controls">
                                        <input class="form-control " id="f_name" name="first_name" minlength="2" type="text" value="<?php echo $f_first_name; ?>"  />
                                    </div>
                                </div>
                                
                                <div class="form-group ">
                                    <label for="l_name" class="control-label">Last Name </label>
                                    <div class="controls">
                                        <input class="form-control " id="l_name" name="last_name" minlength="2" type="text" value="<?php echo $f_last_name; ?>"  />
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label">Profile Picture</label>
                                    <div class="controls">
                                        <div data-provides="fileupload" class="fileupload fileupload-new">
                                            <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                               <!-- <img alt="" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image"> -->
                                            <img alt="" src="<?php echo SITEURL."images/users/".$user->get_current_user()['img_path']; ?>">
                                            </div>
                                            <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                            <div>
                                               <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                               <span class="fileupload-exists">Change</span>
                                               <input type="file" class="default" name="fileToUpload" ></span>
                                            </div>
                                        </div>
                                  </div>
                                </div>
                              
                               <div class="form-group">
                                <label class="control-label">Email Address Input</label>
                                <div class="controls">
                                    <div class="input-icon left">
                                        <i class="icon-envelope"></i>
                                        <input class="form-control" type="email" placeholder="Email Address" value="<?php echo $f_email; ?>" readonly />
                                    </div>
                                </div>
                              </div>
                                
                                <div class="form-group">
                                <label class="control-label">Dailing Code </label>
                                <div class="controls">
                                    <select class="form-control " data-placeholder="Choose a Category" tabindex="1" name="d_code" value=<?php echo $f_dial_code;?> required >
                                      <option value="055"<?=$f_dial_code == '55' ? ' selected="selected"' : '';?>>(055)</option> 
                                       <option value="92"<?=$f_dial_code  == '92' ? ' selected="selected"' : '';?>>(92)</option> 
                                    </select>
                                </div>
                              </div>

                              <div class="form-group ">
                                    <label for="phone_no" class="control-label">Phone No. </label>
                                    <div class="controls">
                                        <input class="form-control " id="phone_no" type="text" name="phone_no" value="<?php echo $f_phone_no; ?>" required />
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="country" class="control-label">Country </label>
                                    <div class="controls">
                                        <input class="form-control " id="country" type="text" name="country" value="<?php echo $f_country; ?>" required />
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="city" class="control-label">City </label>
                                    <div class="controls">
                                        <input class="form-control " id="city" type="text" name="city" value="<?php echo $f_city; ?>" required />
                                    </div>
                                </div>

                             <div class="form-actions"> 
                                    <button class="btn btn-success" type="submit" name="reg" value=""><?php echo $btn; ?></button>
                                    <button class="btn" type="button">Cancel</button>
                                </div>
                            </form>
                         </div>
                        </div>
                        <!-- END FORM-->
						<!--End contents-->
						
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <!--End scripts-->
</body>

</html>
