<!DOCTYPE html>
<?php
require_once('../init.php');

if (!$user->is_login_admin())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

if (isset($_POST['done_vals']))
	{
	 $department_data = array(
		        'department_name'=> $_POST['dep_name'],
		        'dep_head'       => $_POST['dep_hod']
						);
	$db->insert_values($department_data,"department");
	}

if (isset($_POST['update_vals']))
	{
	 $up_department_data = array(
		        'department_name'=> $_POST['up_dep_name'],
		        'dep_head'       => $_POST['up_dep_hod']
						);
	$db->update_values($up_department_data,"department",$_POST['have_id']);
	}

$hod_sql   = "SELECT first_name, last_name,id FROM ".PREFIX."users "; 
$hod_fetch = $db->fetch_all($hod_sql);
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Departments</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Manage departments</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Manage and modify departments</div>
					<div class="panel-body">
						<!--Start contents form here-->
						<div class="row">
								<div class="panel-body">
									<a class="js-open-modal btn" href="#" data-modal-id="popup_add"><img src="images/data-add-icon.png" alt="image not available"/></a> 
									<table data-toggle="table" data-url=""  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
									    <thead>
									    <tr>
									       <!-- <th data-field="state" data-checkbox="true" >Item ID</th> This is for multiple selection checkbox-->
									        <th data-field="sr" data-sortable="true">Sr#</th>
									        <th data-field="dep"  data-sortable="true">Department</th>
									        <th data-field="hod" data-sortable="true">Head of Department</th>
									        <th data-field="ac" data-sortable="true">Actions</th>
									    </tr>
									    </thead>
									    <tbody>
									     <?php
									     $custom_fun->show_departments();
									     ?>
									    </tbody>
									</table>
								</div>
							</div>
						</div>

						<!--Start Popup model Add-->
						<div id="popup_add" class="modal-box">
						  <header> <div class="js-modal-close close"><img src="images/Button-Close-icon.png" alt="x"/></div>
						    <h3>Add department</h3>
						  </header>
						  <div class="modal-body">
						    <p>
						      <!--Start Contents from here-->
								<div class="row">
								   <div class="col-md-6">
								   <form role="form" method="POST"> 
								    <div class="form-group">
								      <input class="form-control"
								      placeholder="Department name" name="dep_name" required/>
								    </div>
								    <div class="form-group">
								    <select name='dep_hod' class='form-control' tabindex='-1' id='1'>       
                                    <option>Select HOD</option>
                                    <?php
                                      $f_category ="";
                                      foreach ($hod_fetch as $key => $hod_values) {
                                        echo '<option value="'.$hod_values['id'].'"';

                                          if ($hod_values['first_name'] == $f_category) 

                                          {
                                            echo 'selected="selected" >';
                                          }
                                          
                                          else
                                          {
                                            echo '>';
                                          }
     
                                        echo $hod_values['first_name']." ".$hod_values['last_name'].'</option>';
                                      }
                                    ?>                 
                                    </select>
								    </div>
								  </div>
								</div>
						      <!--End Contents-->
						    </p>
						  </div>
						  <footer> 
                          <button type="submit" class="btn_pop" name="done_vals">Add</button>  
                          <div class="btn_pop js-modal-close">Close</div>  
						  </form>
						  </footer>
						</div>
						<!--End Popup model Add-->

					<!--Start Popup model Edit-->
					      <?php
                  			$all_department = $db->fetch_all("SELECT * FROM ".PREFIX."department");
                  			foreach ($all_department as $key => $fetched_department) {
                          ?>
						<div id="popup_edit<?php echo $fetched_department['id'];?>" class="modal-box">
						  <header> <div class="js-modal-close close"><img src="images/Button-Close-icon.png" alt="x"/></div>
						    <h3>Update department</h3>
						  </header>
						  <div class="modal-body">
						    <p>
						      <!--Start Contents from here-->
							  <?php 
                              $fetch_details   = "SELECT * FROM ".PREFIX."department WHERE id=".$fetched_department['id']; 
                              $fetched_details = $db->fetch_single_row($fetch_details);
                              $dep_name  = $fetched_details['department_name']; 
                              $head_name = $fetched_details['dep_head'];
                              ?>
								<div class="row">
								   <div class="col-md-6">
								   <form role="form" method="POST"> 
								    <div class="form-group">
								      <input class="form-control"
								      placeholder="Department name" name="up_dep_name" value="<?php echo $dep_name; ?>" required/>
								    </div>
								    <div class="form-group">
								    <select name='up_dep_hod' class='form-control' tabindex='-1' id='1'>       
                                    <option>Select HOD</option>
                                    <?php
                                      foreach ($hod_fetch as $key => $hod_values) {
                                        echo '<option value="'.$hod_values['id'].'"';

                                          if ($hod_values['id'] == $head_name) 

                                          {
                                            echo 'selected="selected" >';
                                          }
                                          
                                          else
                                          {
                                            echo '>';
                                          }
     
                                        echo $hod_values['first_name']." ".$hod_values['last_name'].'</option>';
                                      }
                                    ?>                 
                                    </select>
								    <input type="hidden" name="have_id" value="<?php echo  $fetched_details['id'] ?>">
								    </div>
								  </div>
								</div>
						      <!--End Contents-->
						    </p>
						  </div>
						  <footer> 
                          <button type="submit" class="btn_pop" name="update_vals">Update</button>  
                          <div class="btn_pop js-modal-close">Close</div>  
						  </form>
						  </footer>
						</div>
						<?php
                          }
                        ?>

						<!--End Popup model Edit-->


						<!--Start Popup model delete-->
						
                          <?php
                  			$all_department = $db->fetch_all("SELECT * FROM ".PREFIX."department");
                  			foreach ($all_department as $key => $fetched_department) {
                          ?>
                          <div id="popup<?php echo $fetched_department['id']; ?>" class="modal-box">
						  <header> <div class="js-modal-close close"><img src="images/Button-Close-icon.png" alt="x"/></div>
						    <h4>Confirm box</h4>
						  </header>
						  <div class="modal-body">
						    <p>
						     <?php 
                              $fetch_details   = "SELECT * FROM ".PREFIX."department WHERE id=".$fetched_department['id']; 
                              $fetched_details = $db->fetch_single_row($fetch_details);
                              ?>
						      <!--Start Contents from here-->
							  Are you sure you want to delete <?php echo $fetched_details['department_name']; ?>?  
							  <!--End Contents-->
						    </p>
						  </div>
						  <footer> 
                          <button class="btn_pop cm_del" name="done_vals" id='<?php echo $fetched_department['id']; ?>' >Okay</button>  
                          <button class="btn_pop js-modal-close">Cancel</button>  
						  </form>
						  </footer>
						</div>
						<!--End Popup model delete-->
						<?php
                          }
                        ?>



						<!--End contents-->
						
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
	<script>
	$(document).ready(function(){
	     
	    $(".cm_del").click(function(){
	         
	         var id = $(this).attr("id");
	         window.location.replace("<?php echo SITEURL; ?>del_department/?id="+id);
	    });
	});
	</script>   
   <!--End scripts-->	
</body>

</html>
