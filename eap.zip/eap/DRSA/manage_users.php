<!DOCTYPE html>
<?php
require_once('../init.php');

if (!$user->is_login_admin())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

if (isset($_GET['action']) && $_GET['action'] == 'active' )
  {
  $user->active_stuff("users","active");
  }
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Users</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">User Managment</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Modify/Delete users</div>
					<div class="panel-body">
						<!--Start contents form here-->
			            <table data-toggle="table" data-url=""  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						       <!-- <th data-field="state" data-checkbox="true" >Item ID</th> This is for multiple selection checkbox-->
						        <th data-field="sr"  data-sortable="true">Sr#</th>
						        <th data-field="full_name" data-sortable="true">Full Name</th>
						        <th data-field="email" data-sortable="true">Eamil</th>
						        <th data-field="level_access" data-sortable="true">Access Level</th>
						        <th data-field="last_login" data-sortable="true">Last Login</th>
						        <th data-field="status" data-sortable="true">Status</th>
						        
						        <th data-field="ac" data-sortable="true">Actions</th>
						    </tr>
						    </thead>
						    <tbody>
						     <?php
						     $user->show_users();
						     ?>
						    </tbody>
						</table>
						<!--End contents-->
						
						<!--Start Popup model delete-->
                          <?php
                  			$all_users = $db->fetch_all("SELECT * FROM ".PREFIX."users");
                  			foreach ($all_users as $key => $fetched_users) {
                          ?>
                          <div id="popup<?php echo $fetched_users['id']; ?>" class="modal-box">
						  <header> <div class="js-modal-close close"><img src="images/Button-Close-icon.png" alt="x"/></div>
						    <h4>Confirm box</h4>
						  </header>
						  <div class="modal-body">
						    <p>
						     <?php 
                              $fetch_details   = "SELECT * FROM ".PREFIX."users WHERE id=".$fetched_users['id']; 
                              $fetched_details = $db->fetch_single_row($fetch_details);
                              ?>
						      <!--Start Contents from here-->
							  Are you sure you want to delete user <?php echo $fetched_details['first_name']." ".$fetched_details['last_name']; ?>?  
							  <!--End Contents-->
						    </p>
						  </div>
						  <footer> 
                          <button class="btn_pop cm_del" name="done_vals" id='<?php echo $fetched_users['id']; ?>' >Okay</button>  
                          <button class="btn_pop js-modal-close">Cancel</button>  
						  </form>
						  </footer>
						</div>
						<?php
                          }
                        ?>
                        <!--End Popup model delete-->
						
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <script>
	$(document).ready(function(){
	     
	    $(".cm_del").click(function(){
	         
	         var id = $(this).attr("id");
	         window.location.replace("<?php echo SITEURL; ?>DRSA/del_user/?id="+id);
	    });
	});
	</script>   
   <!--End scripts-->
</body>

</html>
