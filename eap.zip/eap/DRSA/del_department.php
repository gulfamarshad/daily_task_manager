<!doctype html>
<?php
require_once('../init.php');

if (!$user->is_login_admin())
{
  header('location: login.php');
}

$user->delete_stuff('department');

?>