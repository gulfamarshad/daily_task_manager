	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li class="active"><a href="<?php echo SITEURL."DRSA/"?>"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
			<li><a href="<?php echo SITEURL."DRSA/manage_departments/"?>"><span class="glyphicon glyphicon-th-list"></span>Departments</a></li>
			<li class="parent ">
				<a href="<?php echo SITEURL."DRSA/change_password/"?>">
					<span data-toggle="collapse" href="#sub-item-2"><span class="glyphicon glyphicon-cog"></span> Account Settings </span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li>
						<a class="" href="<?php echo SITEURL."DRSA/profile/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Profile Settings
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRSA/change_password/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Change Password 
						</a>
					</li>
				</ul>
			</li>
			<li class="parent ">
				<a href="<?php echo SITEURL."DRSA/add_users/"?>">
					<span data-toggle="collapse" href="#sub-item-3"><span class="glyphicon glyphicon-user"></span> Users </span>
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li>
						<a class="" href="<?php echo SITEURL."DRSA/add_users/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Create Users
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRSA/manage_users/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Manage Users
						</a>
					</li>
				</ul>
			</li>
			<li role="presentation" class="divider"></li>
			
		</ul>

	</div><!--/.sidebar-->