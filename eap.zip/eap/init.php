<?php
if (!isset($_SESSION)) {
  session_start();
}
  
  define("PREFIX", "sr_");
  define("UPLOAD_DIR", "../images/users/");
  define("SITEURL", "http://localhost/eap/", true); //When enter ip address then it redirect without login
  //define("SHOW_IMG","http://pms.net.pk/upload_videos_admin/uv-admin-pannel/imgs");
  $db_name="localhost";
  $user_name="root";
  $password="";
  $sl_db="db_dilay_activity_report";

  require_once("libs/db_op_class.php");
  $db= new db_op();
  $db->db_connect($db_name,$user_name,$password,$sl_db);

  require_once("libs/users_class.php");
  $user = new user();
  
  require_once("libs/sec_class.php");
  $sec = new security();

  require_once("libs/class_functions.php");
  $custom_fun = new custom_functions();

  require_once("libs/class_leads.php");
  $obj_lead = new leads();
  ?>

  <script src="js/jquery.min.js"></script>

  <!--Desktop Notification-->
     <div id="ref">
     <div class="for-ref">
     <?php
      if ($user->is_login_TeamMember())
       {
       $found_assignment = NULL;
       $assignemnt_fetch = "SELECT assignment FROM ".PREFIX."tasks";
       $specific = $db->fetch_all($assignemnt_fetch);
       foreach ($specific as $key => $value_assignment) {
        /*Start Multiple*/
        $mafe = explode(",", $value_assignment['assignment']);
        $max  = count($mafe);
        /*End Multiple*/
        
        for ($i=0; $i < $max; $i++) { 
           if ($mafe[$i] == $user->get_current_user()['id'] )
               {
                $found_assignment++;
               }
        }
       }
       }
      
      else
      {
        $found_assignment = 0;
      }

     ?>
     <input id="get_val" type="hidden" value="<?php echo $found_assignment; ?>">
     </div>
     </div>
     
     <div style="display:none;">
     <audio id="noti" controls>
     <source src="<?php echo SITEURL;?>includes/sounds/task_notification.ogg" type="audio/ogg">
     <source src="<?php echo SITEURL;?>includes/sounds/task_notification.mp3" type="audio/mp3">
     </audio>
     </div>
<!--End Desktop Notification-->


<!--Desktop Notification for Admin-->
     <div id="ref-cmnts">
     <div class="for-ref-cmnts">
     <?php
      if ($user->is_login_hod())
       {
         $select_sql   = "SELECT id FROM ".PREFIX."task_comments";  
         $comments = $db->number_rows_hide($select_sql);
         $latest_comment_sql = "SELECT task_comments,user_id FROM ".PREFIX."task_comments WHERE id = (SELECT max(id) FROM ".PREFIX."task_comments)";  
         $latest_comment = $db->fetch_single_row($latest_comment_sql)['task_comments'];
         $cmnt_user_id = $db->fetch_single_row($latest_comment_sql)['user_id'];
         $cmnt_user_sql = "SELECT first_name, last_name FROM ".PREFIX."users WHERE id = ".$cmnt_user_id." ";
         $cmnt_user = $db->fetch_single_row($cmnt_user_sql)['first_name']." ".$db->fetch_single_row($cmnt_user_sql)['last_name'];
       }
      else
      {
        $comments = 0;
        $latest_comment = NULL;
      }
     ?>
     <input id="cmnt_val" type="hidden" value="<?php echo $comments; ?>">
     <input id="latest_comment" type="hidden" value="<?php echo $custom_fun->cleanOut($latest_comment)." by (".$cmnt_user.")" ; ?>">
     </div>
     </div>
<!--End Desktop Notification for Admin-->