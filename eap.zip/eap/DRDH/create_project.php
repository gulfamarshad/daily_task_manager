<!DOCTYPE html>
<?php
require_once('../init.php');

$project_dep = $user->get_current_user()['department'];
if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}
 
else{
		if (isset($_GET['id'])) 
		 {
		 $fetch_data_sql = "SELECT * FROM ".PREFIX."projects WHERE id=".base64_decode($_GET['id']); 
		 $result_fetch = $db->fetch_single_row($fetch_data_sql);
		 
		 $f_project_code     = $result_fetch['id'];
		 $f_project_name     = $result_fetch['project_name'];
		 $f_department_name  = $result_fetch['department_of'];
		 $f_starting_date    = $result_fetch['starting_date'];
		 $f_ending_date      = $result_fetch['ending_date'];
		 $f_customer_details = $result_fetch['customer_details'];
		 $f_status           = $result_fetch['status'];
		 $f_comments         = $result_fetch['comments'];
		 $btn                = "Update";
		 $readonly		     = "readonly";
		 
		 if (isset($_POST['done']))
			   {
			   	 $project_data = array('project_name'     => $_POST['project_name'],
			   	 					   'department_of'    => $project_dep,
			   	 					   'starting_date'    => $_POST['start_date'],
			   	 					   'ending_date'      => $_POST['end_date'],
			   	 					   'status'           => $_POST['act_status'],
			   	 					   'customer_details' => mysql_real_escape_string($_POST['customer_details']),
			   	 					   'comments'         => mysql_real_escape_string($_POST['comments'])
			   	 					  );
			   	 $db->update_values($project_data, "projects");
			   	 
			   	 $phases = $_POST['phase_new'];
			   	 //echo implode("_", $phases);
			   	 //$del_values = "DELETE FROM ".PREFIX."phases WHERE project_code =".$f_project_code;
			   	 //$db->run_query($del_values);
			   	 
			   	 foreach ($phases as $key => $value) {
			   	 	     
			   	 	     $ins_query = "INSERT INTO ".PREFIX."phases (project_code, phase) VALUES ('".$f_project_code."', '".$value."')";
					     $db->run_query ($ins_query);
			   	 }
			   
			   } 
		 }

		if(!isset($_GET['id']))
		{
		 $f_project_name     = "";
		 $f_starting_date    = "";
		 $f_ending_date      = "";
		 $f_customer_details = "";
		 $f_status           = "";
		 $f_comments         = "";
		 $btn                = "Save";
		 $readonly		     = "";

			if (isset($_POST['done']))
			   {
			   	 $project_data = array('project_name'     => $_POST['project_name'],
			   	 					   'department_of'    => $project_dep,
			   	 					   'starting_date'    => $_POST['start_date'],
			   	 					   'ending_date'      => $_POST['end_date'],
			   	 					   'status'           => $_POST['act_status'],
			   	 					   'customer_details' => $_POST['customer_details'],
			   	 					   'comments'         => $_POST['comments']
			   	 					  );
			   	 $db->insert_values($project_data, "projects");
			   	 $phases = $_POST['phase_new'];
			   	 $project_code = mysql_insert_id();
			   	 foreach ($phases as $key => $value) {
			   	 	     $ins_query = "INSERT INTO ".PREFIX."phases (project_code, phase) VALUES ('".$project_code."', '".$value."')";
					     $db->run_query ($ins_query);
			   	 }
			   }
		}
}
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>New Project</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">New Projects</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Add new projects</div>
					<div class="panel-body">
						<!--Start contents form here-->
						<div class="row">
						<div class="col-md-6">
						<form class="" id="commentForm" method=
							"post" action="" enctype="multipart/form-data">
							  <div class="form-group">
							    <label for="f_name" class="">* Project Name
							     </label>
							    <div class="controls">
							      <input class="form-control" id="project_name" name="project_name" minlength=
							      "2" type="text" value="<?php echo $f_project_name; ?>"
							      required="" />
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="l_name" class="">* Starting Date
							    </label>
							    <div class="controls">
							      <input class="form-control" id="" name="start_date" minlength=
							      "2" type="date" value="<?php echo $f_starting_date; ?>" required
							       <?php echo $readonly; ?>/>
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="l_name" class=""> Expected Ending Date
							    </label>
							    <div class="controls">
							      <input class="form-control" id="" name="end_date" minlength=
							      "2" type="date" value="<?php echo $f_ending_date; ?>"/>
							    </div>
							  </div>
							  <div class="form-group">
							    <span class="btn btn-primary add_field_button">Add Phase</span>
							  </div>
							   
							   <div class="input_fields_wrap">
							   	<?php
							   	 /*Fetching phases according to projects*/
								 if (isset($_GET['id']))
								    {
									 $fetch_phases = "SELECT * FROM ".PREFIX."phases WHERE project_code=".base64_decode($_GET['id']);
									 $number       = $db->number_rows_hide($fetch_phases);
									 $fetched_phases = $db->fetch_all($fetch_phases);
									 foreach ($fetched_phases as $key => $phase_value) {
									 	echo '<div><input style="margin-top: 10px;" type="text" class="form-control" name="phase[]" value="'.$phase_value['phase'].'" readonly></div>';
									 }
							    	}
							    ?>
							   </div>

							   <div class="form-group">
							    <label class="">* Status</label>
							    <div class="controls">
							      <select class="form-control" data-placeholder="Choose a Category"
							      tabindex="1" name="act_status" required="">
							        <option value=
							        "1" <?=$f_status == '1' ? ' selected="selected"' : '';?>>
							          Active
							        </option>
							        <option value=
							        "0" <?=$f_status  == '0' ? ' selected="selected"' : '';?>>
							          Inactive
							        </option>
							      </select>
							    </div>
							  </div>

							   <div class="form-group">
							    <label for="l_name" class="">* Customer Details 
							    </label>
							    <div class="controls">
							      <textarea class="form-control" rows="3" name="customer_details" required>
							      	<?php echo $f_customer_details; ?>
							      </textarea>
							      </div>
							  </div>
							   <div class="form-group">
							    <label for="l_name" class="">Comments 
							    </label>
							    <div class="controls">
							      <textarea class="form-control" rows="3" name="comments">
							      	<?php echo $f_comments; ?>
							      </textarea>
							    </div>
							  </div>
							  <div class="">
							    <button class="btn btn-primary" type="submit" name="done" value=
							    ""><?php echo $btn; ?></button> <button class="btn" type=
							    "button">Cancel</button>
							  </div>
							</form><!-- END FORM-->
						</div>
						</div>	
						<!--End contents-->
						
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>

   <!--This is for creating dynamic textboxes-->
	<script>
	$(document).ready(function() {
	    var max_fields      = 20; //maximum input boxes allowed
	    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
	    var add_button      = $(".add_field_button"); //Add button ID
	    
	    var x = 0; //initlal text box count
	    $(add_button).click(function(e){ //on add input button click
	        e.preventDefault();
	        if(x < max_fields){ //max input box allowed
	            x++; //text box increment
	            $(wrapper).append('<div><input style="margin-top: 10px;" type="text" name="phase_new[]" class="form-control" placeholder="phase" required/><a href="#" class="remove_field"><span style="margin-top: 10px;">x</a></div>'); //add input box
	        }
	    });
	    
	    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
	        e.preventDefault(); $(this).parent('div').remove(); x--;
	    })
	});
	</script>
   <!--End scripts-->
</body>

</html>
