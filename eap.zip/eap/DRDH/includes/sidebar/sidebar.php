	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		
		<ul class="nav menu">
			<li class="active"><a href="<?php echo SITEURL."DRDH/"?>"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
			<li class="parent ">
				<a href="<?php echo SITEURL."DRDH/change_password/"?>">
					<span data-toggle="collapse" href="#sub-item-3"><span class="glyphicon glyphicon-cog"></span>Account Settings</span>  
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/profile/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Profile Settings
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/change_password/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Change Password 
						</a>
					</li>
				</ul>
			</li>
			<li class="parent ">
				<a href="<?php echo SITEURL."DRDH/add_members/"?>">
					<span data-toggle="collapse" href="#sub-item-2"><span class="glyphicon glyphicon-user"> Members </span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/add_members/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Create Member
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/manage_members/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Manage Members
						</a>
					</li>
				</ul>
			</li>
			<li class="parent ">
				<a href="<?php echo SITEURL."DRDH/create_project/"?>">
					<span data-toggle="collapse" href="#sub-item-4"><span class="glyphicon glyphicon-briefcase"></span>Projects Bucket</span>  
				</a>
				<ul class="children collapse" id="sub-item-4">
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/create_project/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> New Project
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/manage_projects/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Running Projects 
						</a>
					</li>
				</ul>
			</li>

			<li class="parent ">
				<a href="<?php echo SITEURL."DRDH/add_task/"?>">
					<span data-toggle="collapse" href="#sub-item-5"><span class="glyphicon glyphicon-list-alt"></span> Tasks </span>
				</a>
				<ul class="children collapse" id="sub-item-5">
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/add_task/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Add new task
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/manage_tasks/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Manage Tasks 
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/task_details/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Task Details
						</a>
					</li>
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/task_comments/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Task Comments
						</a>
					</li>
				</ul>
			</li>
			
			<li class="parent ">
				<a href="<?php echo SITEURL."DRDH/daily_report/"?>">
					<span data-toggle="collapse" href="#sub-item-6"><span class="glyphicon glyphicon-th-large"></span>Reporting</span>  
				</a>
				<ul class="children collapse" id="sub-item-6">
					<li>
						<a class="" href="<?php echo SITEURL."DRDH/daily_report/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Daily Reporting
						</a>
					</li>

					<li>
						<a class="" href="<?php echo SITEURL."DRDH/datewise_report/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Date Wise Reporting
						</a>
					</li>
			        
			        <li>
						<a class="" href="<?php echo SITEURL."DRDH/members_report/"?>">
							<span class="glyphicon glyphicon-chevron-right"></span> Member Wise Reporting
						</a>
					</li>
				</ul>
			</li>
			<li role="presentation" class="divider"></li>
		</ul>

	</div><!--/.sidebar-->