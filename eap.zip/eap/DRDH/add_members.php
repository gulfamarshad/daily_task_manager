<!DOCTYPE html>
<?php
require_once('../init.php');
if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

if (!isset($_GET['id']))
 {
 $f_first_name     = "";
 $f_last_name      = "";
 $f_department     = "";
 $f_access_level   = "Select...";
 $f_dial_code      = "Select...";
 $f_active         = "Select...";
 $f_phone_no       = "";
 $f_email          = "";
 $f_country        = "";
 $f_city           = "";
 $btn              = "Save";
 $pw_text_box      = "required";
 
 if (isset($_POST['reg']))
   {
    $user->register_user();
   }
 }


if (isset($_GET['id']) AND isset($_GET['HFLsohf']))
 {
 $fetch_data_sql = "SELECT * FROM ".PREFIX."users WHERE id=".base64_decode($_GET['id']); 
 $result_fetch = $db->fetch_single_row($fetch_data_sql);
 
 $f_first_name     = $result_fetch['first_name'];
 $f_last_name      = $result_fetch['last_name'];
 $f_department     = $result_fetch['department'];
 $f_access_level   = $result_fetch['level_access'];
 $f_active         = $result_fetch['active'];
 $f_dial_code      = $result_fetch['dialing_code'];
 $f_phone_no       = $result_fetch['phone'];
 $f_email          = $result_fetch['email'];
 $f_country        = $result_fetch['country'];
 $f_city           = $result_fetch['city'];
 $btn              = "Update";
 $pw_text_box      = "";
 
 if (isset($_POST['reg']))
   {

  $user->update_user();

   }
 
 }
$department_sql   = "SELECT * FROM ".PREFIX."department WHERE id = ".$user->get_current_user()['department']." "; 
$department_fetch = $db->fetch_all($department_sql);
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create uses</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Create Members</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
				<div class="panel panel-default">
					<!-- <div class="panel-heading">Create new users</div> -->
					<div class="panel-body">
						<!--Start contents form here-->
							<div class="row">
							<div class="col-md-6">
							<form class="" id="commentForm" method=
							"post" action="" enctype="multipart/form-data">
							  <div class="form-group">
							    <label for="f_name" class="">* First Name
							     </label>
							    <div class="controls">
							      <input class="form-control" id="f_name" name="first_name" minlength=
							      "2" type="text" value="<?php echo $f_first_name; ?>"
							      required="" />
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="l_name" class="">* Last Name
							    </label>
							    <div class="controls">
							      <input class="form-control" id="l_name" name="last_name" minlength=
							      "2" type="text" value="<?php echo $f_last_name; ?>" required=
							      "" />
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="l_name" class="">* Department
							    </label>
							    <div class="controls">
							       <select class="form-control" name="dep_name" required readonly>
							       <?php
							       foreach ($department_fetch as $key => $value_dep) {
							             echo '<option value="'.$value_dep['id'].'" selected>'.$value_dep['department_name'].'</option>';	
							       }
							       
							       ?>
							       <select>
							    </div>
							  </div>
							  <?php  
                                  if (!isset($_GET['id']))
                                  {
                                   echo $img_code =
                                   '
                                   <div class="form-group">
                                        <label class="">Profile Picture</label>
                                        <div class="controls">
                                            <div data-provides="fileupload" class="fileupload fileupload-new">
                                                <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                                    <img alt="" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image">
                                                </div>
                                                <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                                <div>
                                                   <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                                   <span class="fileupload-exists">Change</span>
                                                   <input type="file" class="default" name="fileToUpload"></span>
                                                </div>
                                            </div>
                                      </div>
                                    </div>';
                                    }

                                    if(isset($_GET['id']))
                                    {
                                     echo $img_code =""; 
                                    }
	                              ?>
							  <div class="form-group">
							    <label class="">* Access Level</label>
							    <div class="controls">
							      <select class="form-control" data-placeholder="Choose a Category"
							      tabindex="1" name="ac_level" id="ss" required="" readonly>
							        <option value=
							        "3" <?=$f_access_level == '3' ? ' selected="selected"' : '';?>>
							        Team Member
							        </option>
							      </select>
							    </div>
							  </div>
							  <div class="form-group">
							    <label class="">* Status</label>
							    <div class="controls">
							      <select class="form-control" data-placeholder="Choose a Category"
							      tabindex="1" name="act_status" required="">
							        <option value=
							        "1" <?=$f_active == '1' ? ' selected="selected"' : '';?>>
							          Active
							        </option>
							        <option value=
							        "0" <?=$f_active  == '0' ? ' selected="selected"' : '';?>>
							          Inactive
							        </option>
							      </select>
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="cemail" class="">* E-Mail
							    </label>
							    <div class="controls">
							      <input class="form-control" id="cemail" type="email" name="email"
							      value="<?php echo $f_email; ?>" required="" />
							      <div id="ermsg" style="color: red;"></div>
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="cemail" class="">Password (<?php echo $pw_text_box; ?>)
							    </label>
							    <div class="controls">
							      <input class="form-control" id="p_w" type="password" name="p_w"
							      value="" <?php echo $pw_text_box; ?> />
							    </div>
							  </div>
							  <div class="form-group">
							    <label class="">* Dailing Code</label>
							    <div class="controls">
							      <select class="form-control" data-placeholder="Choose a Category"
							      tabindex="1" name="d_code" value="<?php echo $f_dial_code;?>"
							      required="">
							        <option value=
							        "055" <?=$f_dial_code == '55' ? ' selected="selected"' : '';?>>
							        (055)
							        </option>
							        <option value=
							        "92" <?=$f_dial_code  == '92' ? ' selected="selected"' : '';?>>
							        (92)
							        </option>
							      </select>
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="phone_no" class="">* Phone No.
							    </label>
							    <div class="controls">
							      <input class="form-control" id="phone_no" type="text" name=
							      "phone_no" value="<?php echo $f_phone_no; ?>" required="" />
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="country" class="">* Country
							    </label>
							    <div class="controls">
							      <input class="form-control" id="country" type="text" name="country"
							      value="<?php echo $f_country; ?>" required="" />
							    </div>
							  </div>
							  <div class="form-group">
							    <label for="city" class="">* City</label>
							    <div class="controls">
							      <input class="form-control" id="city" type="text" name="city" value=
							      "<?php echo $f_city; ?>" required="" />
							    </div>
							  </div>
							  <div class="">
							    <button class="btn btn-primary" type="submit" name="reg" value=
							    ""><?php echo $btn; ?></button> <button class="btn" type=
							    "button">Cancel</button>
							  </div>
							</form><!-- END FORM-->
						  </div>
						  </div>
						  
						<!--End contents-->
					</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <!--End scripts-->
</body>

</html>
