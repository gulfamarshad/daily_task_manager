<!doctype html>
<?php
require_once('../init.php');

if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}
$COM_SQL = "UPDATE ".PREFIX."projects SET complete_status = '1'  WHERE id = ".$_GET['id']." ";
$db->run_query($COM_SQL);
$custom_fun->redirect_page(''.SITEURL.'DRDH/manage_projects/');
?>