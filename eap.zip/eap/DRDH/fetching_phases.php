<?php
require_once('../init.php');
if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}
if(isset($_POST["project"])){
    // Capture selected country
    $project = $_POST["project"];
     
    // Fetching phases according to project
    $fetching_phases_sql = "SELECT * FROM ".PREFIX."phases WHERE project_code=".$project;
    $fetched_phases = $db->fetch_all($fetching_phases_sql);
     
    // Display phases based on project
    if($project !== '0'){
      echo '<label>* Select Phase</label>';
       echo "<select class='form-control' name='project_phase' required>";
       echo "<option value=''>Select phase</option>";
       foreach ($fetched_phases as $key => $value_phases) {
             
             /*
             echo '<option value="'.$value_phases['phase'].'"';

              if ($value_phases['phase'] == "desigining") 

              {
                echo 'selected="selected" >';
              }
              
              else
              {
                echo '>';
              }

             echo $value_phases['phase'].'</option>';
            */
       echo '<option value="'.$value_phases['id'].'">'.$value_phases['phase'].'</option>';
       }
      echo "<select>";
    }
}
?>

