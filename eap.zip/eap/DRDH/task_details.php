<!DOCTYPE html>
<?php
require_once('../init.php');

if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}
else
   {
   	
   }
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Task Details</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Task Details</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">All assigned tasks details</div>
					<div class="panel-body">
						<!--Start contents form here-->
							<div class="row">
								<div class="panel-body">
									<table data-toggle="table" data-url=""  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
									    <thead>
									    <th data-field="assign_date" data-sortable="true">Task Details</th>
									    <th data-field="task_details" data-sortable="true">Assigned To</th>
									    <th data-field="mark_comp" data-sortable="true">Mark Completed By</th>
									    <!--
									    <tr>
									        <th data-field="state" data-checkbox="true" >Item ID</th> This is for multiple selection checkbox
									        <th data-field="sr" data-sortable="true">Sr#</th>
									        <th data-field="task_details"  data-sortable="true">Task Details</th>
									        <th data-field="assigned_to" data-sortable="true">Assigned to</th>
									        <th data-field="ac" data-sortable="true">Actions</th>
									    	
									    </tr>
									    -->
									    </thead>
									    
									    <tbody>
									     <?php $custom_fun->show_tasks_details(); ?>
									    </tbody>
									</table>
								</div>
							</div>
						<!--End contents-->
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <!--End scripts-->
</body>

</html>
