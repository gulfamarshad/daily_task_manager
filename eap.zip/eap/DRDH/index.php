<!DOCTYPE html>
<?php
if (!isset($_SESSION))
   {
    session_start();
   } 
require_once('../init.php');
if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

else
{
/*Data for line chart*/
#May be for some logic
/*$months_data = array( 'Junary'      => 1, 
                      'February'    => 2, 
                      'March'       => 9, 
                      'April'       => 4, 
                      'May'         => 5, 
                      'June'        => 9, 
                      'July'        => 7, 
                      'August'      => 8, 
                      'september'   => 9, 
                      'October'     => 10, 
                      'November'    => 9, 
                      'December'    => 12 

                    );*/

$months_data = array( 'Junary'      => 1, 
                      'February'    => 2, 
                      'March'       => 3, 
                      'April'       => 4, 
                      'May'         => 5, 
                      'June'        => 6, 
                      'July'        => 7, 
                      'August'      => 8, 
                      'september'   => 9, 
                      'October'     => 10, 
                      'November'    => 11, 
                      'December'    => 12 

                    );
$current_date = date('Y-m-d');
$year = date("Y",strtotime($current_date));

foreach ($months_data as $key => $value_months) {
  $picking_months = "SELECT id FROM ".PREFIX."projects WHERE MONTH(starting_date) = (".$value_months.") AND YEAR(starting_date) = (".$year.")";
  $picked_months  = $db->number_rows_hide($picking_months);
  $month[] = $picked_months;
}

}
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<script>
var randomScalingFactor = function(){ return Math.round(Math.random()*1000)};
var january    = <?php echo $month[0]; ?>;
var february   = <?php echo $month[1]; ?>;
var march      = <?php echo $month[2]; ?>;
var april      = <?php echo $month[3]; ?>;
var may        = <?php echo $month[4]; ?>;
var june       = <?php echo $month[5]; ?>;
var july       = <?php echo $month[6]; ?>;
var august     = <?php echo $month[7]; ?>;
var september  = <?php echo $month[8]; ?>;
var october    = <?php echo $month[9]; ?>;
var november   = <?php echo $month[10];?>;
var december   = <?php echo $month[11];?>;

	var lineChartData = {
			labels : ["January","February","March","April","May","June","July","August","September","October","November","December"],
			datasets : [
				{
					label: "My First dataset",
					fillColor : "rgba(220,220,220,0.2)",
					strokeColor : "rgba(220,220,220,1)",
					pointColor : "rgba(220,220,220,1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(220,220,220,1)",
					data : [january,february,march,april,may,june,july,august,september,october,november,december]
				},
				
				{
					label: "My Second dataset",
					fillColor : "rgba(48, 164, 255, 0.2)",
					strokeColor : "rgba(48, 164, 255, 1)",
					pointColor : "rgba(48, 164, 255, 1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(48, 164, 255, 1)",
					data : [january,february,march,april,may,june,july,august,september,october,november,december]	
				}
			]

		}
</script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	

	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->

		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Dashboard</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<span class="glyphicon glyphicon-tasks" style="font-size: 50px;"></span>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php $custom_fun->show_hod_assigned_tasks();?></div>
							<div class="text-muted">Today' Tasks</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<span class="glyphicon glyphicon-comment" style="font-size: 50px;"></span>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php $custom_fun->show_comments_tasks();?></div>
							<div class="text-muted">Comments</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<span class="glyphicon glyphicon-check" style="font-size: 50px;"></span>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php $custom_fun->show_completed_tasks();?></div>
							<div class="text-muted">Completed</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-red panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<span class="glyphicon glyphicon-briefcase" style="font-size: 50px;"></span>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php $custom_fun->show_all_projects();?></div>
							<div class="text-muted">Total Projects</div>
						</div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Projects Overview of <?php echo $year; ?></div>
					<div class="panel-body">
						<div class="canvas-wrapper">
							<canvas class="main-chart" id="line-chart" height="200" width="600"></canvas>
						</div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <!--End scripts-->
	
</body>

</html>
