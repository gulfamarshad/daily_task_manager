<!DOCTYPE html>
<?php
require_once('../init.php');
if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

$user_department = $user->get_current_user()['department'];
$fetching_projects_sql = "SELECT * FROM ".PREFIX."projects WHERE department_of=".$user_department;
$fetched_projects = $db->fetch_all($fetching_projects_sql);

if (!$user->is_login_hod())
	{
	  $custom_fun->redirect_page('http://localhost:8080/staff_records/login/');
	}

else
   {
	if (!isset($_GET['id']))   	
	   {
	   	$f_project    = "";
	   	$f_hours      = "";
	   	$f_task_title = "";
	   	$f_phase      = "";
	   	$f_des        = "";
	   	$btn          = "Save";
	   	if (isset($_POST['done']))
	   	 {
		   	$task_data = array('task_title'        => $_POST['task_title'] , 
		   					   'task_timeline'     => $_POST['task_timeline'] , 
		   					   'concerned_project' => $_POST['for_proj'] , 
		   					   'concerned_phase'   => $_POST['project_phase'] , 
		   					   'description'       => $_POST['task_des']  
		   					  );
		    $db->insert_values($task_data,"tasks");
	     }
	   }
    
    if (isset($_GET['id']))
       {
         $fetching_tasks_sql = "SELECT * FROM ".PREFIX."tasks WHERE id=".base64_decode($_GET['id']);
         $result = $db->fetch_single_row($fetching_tasks_sql);

	        $f_project    = $result['concerned_project'];
		   	$f_hours      = $result['task_timeline'];
		   	$f_assignemt  = $result['assignment'];
		   	$f_task_title = $result['task_title'];
		   	$f_phase      = $result['concerned_phase'];
		   	$f_des        = $custom_fun->cleanOut($result['description']);
		   	$btn          = "Update";
		   	
		   	if (isset($_POST['done']))
		    {
		   	if (!isset($_POST['project_phase']))
		   	   {
		   	   	$phase_value = $f_phase; 
		   	   }
		   	else
		   	   {
		   	   	$phase_value = $_POST['project_phase']; 
		   	   }   
		   	$change_assignment = null;
		   	$count_assignment = null;
		   	$max= count($_POST['assigned']);
		   	foreach ($_POST['assigned'] as $key => $assignment) {
		   	         if ($count_assignment == $max-1)
		   	             {
		   	             	$comma = "";
		   	             }
		   	         else
		   	             {
		   	             	$comma = ",";
		   	             }
		   	         $change_assignment.= $assignment.$comma;
		   	         $count_assignment++;
		   	  }  
		   	
		   	   if (isset($_GET['id']))
		   	      {
		   	      	$final_assignment = $change_assignment; 
		   	      }
		   	   
		   	   if (!isset($_GET['id']))
		   	     {
		   	     	$final_assignment = $f_assignemt; 
		   	     }
		   	
		   	
		   	$task_data = array('task_title'        => $_POST['task_title'] , 
		   					   'task_timeline'     => $_POST['task_timeline'] , 
		   					   'assignment'        => $final_assignment,
		   					   'concerned_project' => $_POST['for_proj'] , 
		   					   'concerned_phase'   => $phase_value , 
		   					   'description'       => mysql_real_escape_string($_POST['task_des'])  
		   					  );
            $db->update_values($task_data,"tasks");
            }		
       }
   }
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Add Task</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Tasks</li>
				<li class="active">Create New Task</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Create New Task</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					
					<div class="panel-body">
						<!--Start contents form here-->
						<div class="row">
							<div class="col-md-6">
						    <form method="POST"> <!--Start form-->			
							<div class="form-group">
							    <label for="f_name" class="">* Task title
							     </label>
							    <div class="controls">
							      <input class="form-control" id="" name="task_title" minlength=
							      "2" type="text" value="<?php echo $f_task_title; ?>"
							      required="" />
							    </div>
							  </div>

							  <div class="form-group">
							    <label for="f_name" class="">* Task Timeline
							     </label>
							    <div class="controls">
							     <select name="task_timeline" class="form-control" required>
							     <option value="" <?=$f_hours == '0' ? ' selected="selected"' : '';?>>Select Timeline</option>
							     <option value="1" <?=$f_hours == '1' ? ' selected="selected"' : '';?>> 1 Hour</option>
							     <option value="2" <?=$f_hours == '2' ? ' selected="selected"' : '';?>> 2 Hours</option>
							     <option value="3" <?=$f_hours == '3' ? ' selected="selected"' : '';?>> 3 Hours</option>
							     <option value="4" <?=$f_hours == '4' ? ' selected="selected"' : '';?>> 4 Hours</option>
							     <option value="5" <?=$f_hours == '5' ? ' selected="selected"' : '';?>> 5 Hours</option>
							     <option value="6" <?=$f_hours == '6' ? ' selected="selected"' : '';?>> 6 Hours</option>
							     <option value="7" <?=$f_hours == '7' ? ' selected="selected"' : '';?>> 7 Hours</option>
							     <option value="8" <?=$f_hours == '8' ? ' selected="selected"' : '';?>> 8 Hours</option>
							     </select> 
							    </div>
							  </div>

							  <?php
							  if (isset($_GET['id']))
							  {
							  echo '<div class="form-group">';
							  echo '<label for="f_name" class=""> Assignment';
							  echo '</label>';
							  echo '<div class="controls">';
						      echo '<div class="form-control" style="height: 100px; ">  ';
								   /*Getting assigned list*/
								   	$place_assignment = null;
								   	$multiple_assignment = explode(",", $result['assignment']);
								   	foreach ($multiple_assignment as $key => $value_assignment) {
								   		   $fetching_users = "SELECT id, first_name, last_name FROM ".PREFIX."users WHERE id=".$value_assignment;
								   		   $fetched = $db->fetch_single_row($fetching_users);
								   		   echo "<input name='assigned[]' type='checkbox' value='".$fetched['id']."' checked>"." ".$fetched['first_name']." ".$fetched['last_name'].", ";
								   	}
									    
								echo '</div>';
							    echo '</div>';
							    echo '</div>';
							   }
							  ?>

							  <div class="form-group">
							    <label for="f_name" class="">* For Project
							     </label>
							    <div class="controls">
							      <!-- <select name="for_proj" class="form-control for-phase" required> -->
							      <select name="for_proj" data-placeholder="Choose a Country..." class="chosen-select form-control for-phase"  tabindex="2">
							      	<option value="0">Select Project</option>
							      	<?php
							      	foreach ($fetched_projects as $key => $value_project) {
                                        echo '<option value="'.$value_project['id'].'"';

                                          if ($value_project['id'] == $f_project) 

                                          {
                                            echo 'selected="selected" >';
                                          }
                                          
                                          else
                                          {
                                            echo '>';
                                          }
     
                                        echo $value_project['project_name'].'</option>';
                                      }
							      	?>
							      </select>
							    </div>
							  </div> 

							  <div class="form-group">
							    <div id="response"></div> <!--This div placing data returned from fetching_phases.php-->	   
							  </div>
							  
							  <div class="form-group">
							    <label for="f_name" class="">* Task Description
							     </label>
							    <div class="controls">
							      <textarea class="form-control" rows="3" name="task_des" value="<?php echo $f_des; ?>" required><?php echo $f_des; ?></textarea>	
							    </div>
							  </div>  	 	
							
							 <div class="">
							    <button class="btn btn-primary" type="submit" name="done" value=
							    ""><?php echo $btn; ?></button> <button class="btn" type=
							    "button">Cancel</button>
							 </div>
							</form> <!--End Form-->
							</div>
						</div>
						<!--End contents-->
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   
   <!--For fetching phases according to project-->
	<script type="text/javascript">
	$(document).ready(function(){
	    $("select.for-phase").change(function(){
	        var selectedproject = $(".for-phase option:selected").val();
	        $.ajax({
	            type: "POST",
	            url: "<?php echo SITEURL; ?>DRDH/fetching_phases/",
	            data: { project : selectedproject } 
	        }).done(function(data){
	            $("#response").html(data);
	        });
	    });
	});
	</script>

	<script>
	document.getElementById("myAnchor").addEventListener("click", function(event){
    event.preventDefault()
    });
    </script>
   <!--End scripts-->
</body>

</html>
