<!DOCTYPE html>
<?php
require_once('../init.php');

if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

if (isset($_POST['done_vals']))
	{
	 $department_data = array(
		        'department_name'=> $_POST['dep_name'],
		        'dep_head'       => $_POST['dep_hod']
						);
	$db->insert_values($department_data,"department");
	}

if (isset($_POST['update_vals']))
	{
	 
	 /*Fetching existing member for concatination*/
	 $fetching_sql = "SELECT assignment FROM ".PREFIX."tasks WHERE id=".$_POST['have_id'];
	 $fetched_member = $db->fetch_single_row($fetching_sql)['assignment'];
	 
	 if(empty($fetched_member))
	   {
	   	$place_assignment = $_POST['up_task_assign'];
	   }
	 if(!empty($fetched_member))
	   {
	   	$place_assignment = $fetched_member.",".$_POST['up_task_assign'];
	   }
	 if (!empty($_POST['up_task_assign']))
	    {
           
     $find_dup_sql = "SELECT assignment FROM ".PREFIX."tasks WHERE id=".$_POST['have_id'];
	 $fetch_multiple = $db->fetch_single_row($find_dup_sql)['assignment'];
	 $rets = explode(",", $fetch_multiple);
	 $max = count($rets);

	 for ($i=0; $i<$max; $i++) 
	      {
		 	 if ($_POST['up_task_assign'] == $rets[$i])
		 	   {
		 	   	$dup = 1;
		 	   	break;
		 	   }
	 	    
	 	    else 
	 	       {
	 	       	$dup = 0;
	 	       }
	      }

         
         if ($dup == 1 ) 
            {
               echo '
			 <div class="isa_info" align="center">
	         <i class="fa fa-check"></i>
	         
	         <strong>Alert!</strong> This member already has same task, Please assign another.
	         </div>
	         </div>
	         ';		
            }

          if ($dup == 0)   
             {
          	 $current_date = date('Y/m/d');
          	 $up_assign_data = array(
		        'assignment'     => $place_assignment,
						);
	         $db->update_values($up_assign_data,"tasks",$_POST['have_id']);
	         $ins_query = "INSERT INTO ".PREFIX."assign_date (user_id,task_id,assign_date ) VALUES ('".$_POST['up_task_assign']."','".$_POST['have_id']."','".date('Y/m/d')."')";
	         $db->run_query($ins_query);
	         }
	       
	    }   

	}

$hod_department = $user->get_current_user()['department'];
$member_sql   = "SELECT * FROM ".PREFIX."users WHERE department=".$hod_department; 
$member_fetch = $db->fetch_all($member_sql);
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage All Tasks</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Tasks</li>
				<li class="active">All Tasks</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Manage Tasks</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Manage, Modify and Assign Tasks</div>
					<div class="panel-body">
						<!--Start contents form here-->
						<div class="row">
								<div class="panel-body">
									<table id="example" class="display" cellspacing="0" width="100%">
									    <thead>
									    <tr>
									        <th>Sr#</th>
									        <th>Task Details</th>
									        <th>Assigned to</th>
									        <th>Actions</th>
									    </tr>
									    </thead>
									    <tbody>
									     <?php
									     $custom_fun->show_tasks();
									     ?>
									    </tbody>
									</table>
								</div>
							</div>
						</div>

					<!--Start Popup model Task-assign-->
					      <?php
                  			$all_tasks = $db->fetch_all("SELECT * FROM ".PREFIX."tasks");
                  			foreach ($all_tasks as $key => $fetched_tasks) {
                          ?>

						<div class="modal fade" id="popup_assign<?php echo $fetched_tasks['id'];?>">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title">Task Assigning</h4>
						      </div>
						      <div class="modal-body">
						     <form role="form" method="POST"> 
						     <p>
						      <!--Start Contents from here-->
							  <?php 
                              $fetch_details   = "SELECT * FROM ".PREFIX."tasks WHERE id=".$fetched_tasks['id']; 
                              $fetched_details = $db->fetch_single_row($fetch_details);
                              ?>
								<div class="row">
								   <div class="col-md-6">
								   <form role="form" method="POST"> 
								   <div class="form-group">
								    <label>Select Team Member</label>
								    <select name='up_task_assign' class='form-control' tabindex='-1' id='1'>       
                                    <option value="">Select Team Member</option>
                                    <?php
                                      $head_name = "";
                                      foreach ($member_fetch as $key => $member_values) {
                                        echo '<option value="'.$member_values['id'].'"';

                                          if ($member_values['first_name'] == $head_name) 

                                          {
                                            echo 'selected="selected" >';
                                          }
                                          
                                          else
                                          {
                                            echo '>';
                                          }
     
                                        echo $member_values['first_name']." ".$member_values['last_name'].'</option>';
                                      }
                                    ?>                 
                                    </select>
								    <input type="hidden" name="have_id" value="<?php echo  $fetched_details['id'] ?>">
								    </div>
								  
								  </div>
								</div>
						      <!--End Contents-->
						    </p>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
						        <button type="submit" class="btn btn-primary" name="update_vals">Assign</button>
						      </form>
						      </div>
						    </div>
						  </div>
						</div>
						<?php
                          }
                        ?>

						<!--End Popup model task-assign-->

                        <!--Start Delete Modal-->
						<?php
                  			$all_tasks = $db->fetch_all("SELECT * FROM ".PREFIX."tasks");
                  			foreach ($all_tasks as $key => $fetched_tasks) {
                        ?>
						<div class="modal fade" id="modal<?php echo $fetched_tasks['id']; ?>">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title">Confirm</h4>
						      </div>
						      <div class="modal-body">
						       <p>
							     <?php 
	                              $fetch_details   = "SELECT * FROM ".PREFIX."tasks WHERE id=".$fetched_tasks['id']; 
	                              $fetched_details = $db->fetch_single_row($fetch_details);
	                              ?>
							      <!--Start Contents from here-->
								  Are you sure you want to delete task <?php echo $fetched_tasks['task_title']; ?>?  
								  <!--End Contents-->
						       </p>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
						        <button type="button" class="btn btn-primary cm_del" id='<?php echo $fetched_tasks['id']; ?>'>Confirm</button>
						      </div>
						    </div>
						  </div>
						</div>
						<?php
                          }
                        ?>
                        <!--End Delete Modal-->
                        
						<!--End contents-->
						
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
	<script>
	$(document).ready(function(){
	     
	    $(".cm_del").click(function(){
	         
	         var id = $(this).attr("id");
	         window.location.replace("<?php echo SITEURL; ?>DRDH/del_task/?id="+id);
	    });
	});
	</script>
   <!--End scripts-->	
</body>

</html>
