<!doctype html>
<?php
require_once('../init.php');

if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

$user->delete_stuff('projects');

?>