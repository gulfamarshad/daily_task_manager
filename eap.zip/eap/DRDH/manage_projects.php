<!DOCTYPE html>
<?php
require_once('../init.php');

if (!$user->is_login_hod())
{
  $custom_fun->redirect_page(''.SITEURL.'login/');
}

if (isset($_GET['action']) && $_GET['action'] == 'active' )
  {
  $user->active_stuff("projects","status");
  }
?>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Projects</title>

<!--Start CSS Portion-->
<?php require_once('../includes/styles/styles.php'); ?>
<!--End CSS Portion-->

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<!--Start Header-->
	<?php require_once('../includes/header/header.php'); ?>
	<!--End Header-->

	<!--Start Sidebar-->		
	<?php require_once('includes/sidebar/sidebar.php'); ?>
	<!--End Sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Project Managment</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Modify/Delete projects</div>
					<div class="panel-body">
						<!--Start contents form here-->
			            <table id="example" class="display" cellspacing="0" width="100%">
						    <thead>
						    <tr>
						        <th>Sr#</th>
						        <th>Project Name</th>
						        <th>Starting Date</th>
						        <th>Ending Date</th>
						        <th>Customer</th>
						        <th>Status</th>
						        <th>COM/ST</th>
						        <th>Actions</th>
						    </tr>
						    </thead>
						    <tbody>
						     <?php
						     $custom_fun->show_projects();
						     ?>
						    </tbody>
						</table>
						<!--End contents-->

                        <!--Start Delete Modal-->
						<?php
                  			$all_pro = $db->fetch_all("SELECT * FROM ".PREFIX."projects");
                  			foreach ($all_pro as $key => $fetched_projects) {
                        ?>
						<div class="modal fade" id="popup<?php echo $fetched_projects['id']; ?>">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title">Confirm</h4>
						      </div>
						      <div class="modal-body">
							     <p>
							     <?php 
	                              $fetch_details   = "SELECT * FROM ".PREFIX."projects WHERE id=".$fetched_projects['id']; 
	                              $fetched_details = $db->fetch_single_row($fetch_details);
	                              ?>
							      <!--Start Contents from here-->
								  Are you sure you want to delete project <?php echo $fetched_details['project_name']; ?>?  
								  <!--End Contents-->
							     </p>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
						        <button type="button" class="btn btn-primary cm_del" id='<?php echo $fetched_projects['id']; ?>'>Confirm</button>
						      </div>
						    </div>
						  </div>
						</div>
						<?php
                          }
                        ?>
                        <!--End Delete Modal-->

                        <!--Start Complete Modal-->
						<?php
                  			$all_pro = $db->fetch_all("SELECT * FROM ".PREFIX."projects");
                  			foreach ($all_pro as $key => $fetched_projects) {
                        ?>
						<div class="modal fade" id="popup_complete<?php echo $fetched_projects['id']; ?>">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title">Complete Confirm</h4>
						      </div>
						      <div class="modal-body">
							     <p>
							     <?php 
	                              $fetch_details   = "SELECT * FROM ".PREFIX."projects WHERE id=".$fetched_projects['id']; 
	                              $fetched_details = $db->fetch_single_row($fetch_details);
	                              ?>
							      <!--Start Contents from here-->
								  Are you sure you want to complete project <?php echo $fetched_details['project_name']; ?>?  
								  <!--End Contents-->
							     </p>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
						        <button type="button" class="btn btn-primary cm_complete" id='<?php echo $fetched_projects['id']; ?>'>Confirm</button>
						      </div>
						    </div>
						  </div>
						</div>
						<?php
                          }
                        ?>
                        <!--End Complete Modal-->
						
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->
   
   <!--Start scripts-->
   <?php require_once('../includes/scripts/scripts.php'); ?>
   <script>
	$(document).ready(function(){
	     
	    $(".cm_del").click(function(){
	         
	         var id = $(this).attr("id");
	         window.location.replace("<?php echo SITEURL; ?>DRDH/del_project/?id="+id);
	    });
	});
	</script>

	<script>
	$(document).ready(function(){
	     
	    $(".cm_complete").click(function(){
	         
	         var id = $(this).attr("id");
	         window.location.replace("<?php echo SITEURL; ?>DRDH/complete_project/?id="+id);
	    });
	});
	</script>
   <!--End scripts-->
</body>

</html>
