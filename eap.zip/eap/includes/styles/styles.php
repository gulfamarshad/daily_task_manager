<meta name="viewport" content="width=device-width; initial-scale=1.0;">
<base href="<?php echo SITEURL; ?>" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link href="css/messages_style.css" rel="stylesheet"> <!--For Messages-->
<link href="css/bootstrap-table.css" rel="stylesheet"> <!--For datatables-->
<link href="css/bootstrap-fileupload.css" rel="stylesheet" /> <!--For File preview-->

<!--For latest data-tables-->
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="css/responsive.bootstrap.min.css">
<!--END latest data-tables-->

<!--For Popup-->
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
<link href="http://cdnjs.cloudflare.com/ajax/libs/normalize/3.0.1/normalize.css" rel="stylesheet" type="text/css">
<link href="css/popup_style.css" rel="stylesheet" type="text/css">
<!--End Popup-->

<!--For search Select-->
<link rel="stylesheet" href="css/prism.css">
<link rel="stylesheet" href="css/chosen.css">
<!--End search Select-->
