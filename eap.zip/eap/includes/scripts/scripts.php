    <script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-table.js"></script> <!--datatables-->
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});
		$('#report_date').datepicker({

		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>

	<!--For latest Data-tables-->
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.responsive.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/responsive.bootstrap.min.js"></script>
<script src="js/dataTables.responsive.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable({responsive: true, details: false})
	 var table = $("#example").DataTable();
} );
</script>	
	<!--End latest Data-tables-->

	 <!--For popup-->
	<script>
	$(function(){

	var appendthis =  ("<div class='modal-overlay js-modal-close'></div>");

		$('a[data-modal-id]').click(function(e) {
			e.preventDefault();
	    $("body").append(appendthis);
	    $(".modal-overlay").fadeTo(500, 0.7);
	    //$(".js-modalbox").fadeIn(500);
			var modalBox = $(this).attr('data-modal-id');
			$('#'+modalBox).fadeIn($(this).data());
		});  
	  
	  
	$(".js-modal-close, .modal-overlay").click(function() {
	    $(".modal-box, .modal-overlay").fadeOut(500, function() {
	        $(".modal-overlay").remove();
	    });
	 
	});
	 
	$(window).resize(function() {
	    $(".modal-box").css({
	        top: ($(window).height() - $(".modal-box").outerHeight()) / 2,
	        left: ($(window).width() - $(".modal-box").outerWidth()) / 2
	    });
	});
	 
	$(window).resize();
	 
	});
	</script>
	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-36251023-1']);
	  _gaq.push(['_setDomainName', 'jqueryscript.net']);
	  _gaq.push(['_trackPageview']);

	  (function() {
	    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>
	 <!--End popup-->

	 <script type="text/javascript" src="js/bootstrap-fileupload.js"></script> <!-- For Upload Image preview -->
	<script>
		 $('a.mafeStop').click(function(e)
	{
	    // Special stuff to do when this link is clicked...

	    // Cancel the default action
	    e.preventDefault();
	});
	</script>
	<script src="js/multiple_select.js"></script> <!--For multiple select-->

    <!--Start Desktop Notification-->
    <script>
	// request permission on page load
	document.addEventListener('DOMContentLoaded', function () {
	  if (!Notification) {
	    alert('Desktop notifications not available in your browser. Please try Google Chrome.'); 
	    return;
	  }

	  if (Notification.permission !== "granted")
	    Notification.requestPermission();
	});

	function notifyMe(con_val) {
	  if (Notification.permission !== "granted")
	    Notification.requestPermission();
	  else {
	    var notification = new Notification('Alert', {
	      icon: '<?php echo SITEURL;?>images/bell-alarm-icon.png',
	      body: ''+con_val+'',
	    });

	    notification.onclick = function () {
	      window.open("");      
	    };

	  }
	}
	</script>
   
    <script>
    $(document).ready(
    function()
     {
    var content_task = "You have a new task";
    //Get value of hidden on page load 
    var old_val = $("#get_val").val();
    
    setInterval(function() {
    $("#ref").load(location.href+" #ref>*","");
    $(".for-ref").load(location.href+" .for-ref>*","");
    
    //Get value of hidden on div refresh  
    var new_val = $("#get_val").val();
    if (old_val < new_val)
        {
        	notifyMe(content_task);
        	document.getElementById('noti').play();
        	old_val = new_val; 
        }                       
                           }, 5000);

     }
    );
    
    $(document).ready(
    				function ()
    				{
                     //Get value of hidden on page load 
                      var old_cmnt = $("#cmnt_val").val();
                      setInterval(function() 
                      				{
                      				$("#ref-cmnts").load(location.href+" #ref-cmnts>*","");
    								$(".for-ref-cmnts").load(location.href+" .for-ref-cmnts>*","");	
                      				var new_cmnt = $("#cmnt_val").val();
                      				if (old_cmnt < new_cmnt)
                      				   {
                      				   	var latest =  $('#latest_comment').val();
                      				   	var cmnt_contents = "Comment: ";	
                      				   	var last_comment = cmnt_contents + latest;
                      				   	notifyMe(last_comment);
                      				   	document.getElementById('noti').play();
                      				   	old_cmnt = new_cmnt;
                      				   }
                      				}
                      	          ,7000);
    				}
                     );
    </script>
  <!--End Desktop Notification-->

  <!--For search Select-->
  <script src="js/chosen.jquery.js" type="text/javascript"></script>
  <script src="js/prism.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
  <!--End search Select-->
