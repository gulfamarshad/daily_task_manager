<?php
require_once('init.php');

            if ($user->is_login_admin())
		        {
		            $custom_fun->redirect_page(SITEURL."DRSA/");
		        }
		    if ($user->is_login_hod())
		        {
		        	$custom_fun->redirect_page(SITEURL."DRDH/");
		        }
		    if ($user->is_login_TeamMember())
		        {
		        	$custom_fun->redirect_page(SITEURL."DRTM/");
		        }
		    else
		        {
					$custom_fun->redirect_page(''.SITEURL.'login/');		        	
		        }        
?>