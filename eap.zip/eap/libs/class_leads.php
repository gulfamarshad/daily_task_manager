<?php

 /**

   * leads Class

   * @author Gulfam Khan

   * @copyright 2016

   */
class leads
{
    /*
    * ///////////////////////
    * Add New Lead
    * ///////////////////////
    */
    public function add_new_lead()
    {
        global $db, $custom_fun, $user; 
        $array1 = array(
                  'lead_code'                  => $_POST['order_no'],
                  'customer_id'                => $_POST['id_customer'],
                  'sales_person'               => $user->get_current_user()['id'],
                  'lead_source'                => $_POST['lead_type'],
                  'lead_type'                  => $_POST['source'],
                  'lead_date'                  => $_POST['post_date'],
                  'assumption'                 => $_POST['assumption'],
                  'next_meeting'               => $_POST['next_meeting'],
                  'queried_services'           => 1,
                  'quotation_sent'             => 0,
                  'quotation_status'           => 0,
                  'discount_percent'           => 0,
                  'total_payable'              => 0,
                  'advance_paid'               => '',
                  'else_cost_set'              => '',
                  'agreement_status'           => '',
                  'scope_of_work'              => '',
                  'proposal'                   => '',
                  'agreement'                  => '',
                  'signing_date'               => '',
                  'execution_timeline'         => '',
                  'team_assigned'              => '',
                  'communication_history'      => '',
                  'completion_status'          => '',
                  'delayed_status_by_customer' => '',
                  'completion_date'            => '',
                  'job_completion_letter'      => '',
                  'completion_signed'          => '',
                  'next_reffered'              => '',
                  'comments'                   => ''

                  );

        $main_lead =  $db->insert_new_lead($array1,"leads");
        $lead_id_new = mysql_insert_id ();

        foreach($_POST['menu_parent'] as $key=>$p)
        {
          

            if(isset($p) and !empty($p)){

            

            $array2 = array(

              'lead_id'           =>   $lead_id_new,

              'product_name'      =>   $p,

              'qty'               =>   $_POST['sale_qty'][$key],

              'sales_price'       =>   $_POST['priceu'][$key],

              'purchase_price'    =>   $_POST['pricel'][$key],

              'type'              =>   $_POST['pcs_pr_ordr'][$key],

              'category'          =>   'cat'
              
            );

            

            }

          $this->insert(PREFIX."quried_services",$array2);                      

        }
         
        $custom_fun->redirect_page('manage_leads.php?msg=1');
        

    }

     /*
    * ///////////////////////
    * Insert Function
    * ///////////////////////
    */

    private function insert($table = null, $data)
    {

          
          if ($table === null or empty($data) or !is_array($data)) {

          echo "Invalid array for table: <b>".$table."</b>.";

          return false;

          }

          $q = "INSERT INTO `" . $table . "` ";

          $v = '';

          $k = '';

          

          foreach ($data as $key => $val) :

              $k .= "`$key`, ";

              if (strtolower($val) == 'null')

                  $v .= "NULL, ";

              elseif (strtolower($val) == 'now()')

                  $v .= "NOW(), ";


              else

                  $v .= "'" . $val . "', ";

          endforeach;

          

          $q .= "(" . rtrim($k, ', ') . ") VALUES (" . rtrim($v, ', ') . ");";

          $query = mysql_query($q);

          if ($query) {

              return true;

          } else

              return false;

      }


    /*
    * ///////////////////////
    * Edit New Lead
    * ///////////////////////
    */


        public function edit_lead()
        {
        global $db, $custom_fun, $user; 

        $lead_id_old = $_GET['id'];

        $dell_previous = mysql_query("delete from ".PREFIX."quried_services where lead_id = '".$lead_id_old."'");

        $array1 = array(
               
                'customer_id'                => $_POST['id_customer'],
                'sales_person'               => $user->get_current_user()['id'],
                'lead_source'                => $_POST['source'],
                'lead_type'                  => $_POST['lead_type'],
                'lead_date'                  => $_POST['post_date'],
                'assumption'                 => $_POST['assumption'],
                'next_meeting'               => $_POST['next_meeting'],
                'queried_services'           => 1

                );

        $db->update_values($array1, "leads"); 

        foreach($_POST['menu_parent'] as $key=>$p)
        {
          $produdct_info = $db->fetch_single_row('SELECT * FROM '.PREFIX.'products WHERE id='.$_POST['basic_id'][$key]);

            if(isset($p) and !empty($p)){

            

            $array2 = array(

              'lead_id'           =>   $lead_id_old,

              'product_name'      =>   $p,

              'qty'               =>   $_POST['sale_qty'][$key],

              'sales_price'       =>   $_POST['priceu'][$key],

              'purchase_price'    =>   $_POST['pricel'][$key],

              'type'              =>   $produdct_info['type'],

              'category'          =>   $produdct_info['category']
              
            );

            

            }

          $this->insert(PREFIX."quried_services",$array2);     
         //print_r($array2);


        }

         
        $custom_fun->redirect_page('manage_leads.php?msg=1');
        

    }

     /*
    * ///////////////////////
    * Promote lead to Quotation
    * ///////////////////////
    */

    public function promote_lead()
    {
      global $db, $custom_fun;
      $array1 = array(
                 
                  'quotation_sent'             => 1,
                  'quotation_status'           => 0,
                  'discount_percent'           => isset($_POST['dis_total'])? $_POST['dis_total'] : 0,
                  'total_payable'              => isset($_POST['amount'])? $_POST['amount'] : 0,
                  'advance_paid'               => isset($_POST['paid'])? $_POST['paid'] : 0

                  );
                
                $db->update_values($array1, "leads");
                $custom_fun->redirect_page('manage_queries.php?msg=1');

    }



     /*
    * ///////////////////////
    * Promote Quotation for Agreement
    * ///////////////////////
    */

    public function update_leads()
    {
        global $db,$user;
      
          
          function file_upload_1()
          
          {
          global $db,$user;
          if ($user->is_login_admin())
            {
            $targetfolder = "/img/files/";
            }
                  
                  
            if ($user->is_login_user())
            {
              $targetfolder = "admin/img/files/";
            }

                  $targetfolder = $targetfolder . basename( $_FILES['agreement']['name']) ;
       
                  if(move_uploaded_file($_FILES['agreement']['tmp_name'], $targetfolder))
       
                  {
       
                  //echo "The file ". basename( $_FILES['fileToUpload']['name']). " is uploaded";
                  return $_FILES['agreement']['name'];
                  }

                
            }

            function file_upload_2()
            {
              global $db,$user;
                if ($user->is_login_admin())
                {
                $targetfolder = "/img/files/";
                }
                  
                  
                if ($user->is_login_user())
                {
                  $targetfolder = "admin/img/files/";
                }

                  $targetfolder = $targetfolder . basename( $_FILES['scope_of_work']['name']) ;
       
                  if(move_uploaded_file($_FILES['scope_of_work']['tmp_name'], $targetfolder))
       
                  {
       
                  //echo "The file ". basename( $_FILES['fileToUpload']['name']). " is uploaded";
                  return $_FILES['scope_of_work']['name'];
                  }

                
            }

            function file_upload_3()                
            {
            global $db,$user;
            if ($user->is_login_admin())
              {
              $targetfolder = "/img/files/";
              }
                    
                    
              if ($user->is_login_user())
              {
                $targetfolder = "admin/img/files/";
              }

                  $targetfolder = $targetfolder . basename( $_FILES['img_pro']['name']) ;
       
                  if(move_uploaded_file($_FILES['img_pro']['tmp_name'], $targetfolder))
       
                  {
       
                  //echo "The file ". basename( $_FILES['fileToUpload']['name']). " is uploaded";
                  return $_FILES['img_pro']['name'];
                  }

                
            }

            /*Get Existing Records*/ 
            $get_names=$db->fetch_single_row('SELECT * FROM '.PREFIX.'leads WHERE id='.$_GET['id']);

            if ($_FILES['agreement']['size'] != 0)
               {
                $agreement_name=file_upload_1();
               }
            else
              {
                

                $agreement_name=$get_names['agreement'];
              }   

             if ($_FILES['scope_of_work']['size'] != 0)
               {
                $scope_of_work=file_upload_2();
               }
             else
               {
                $scope_of_work=$get_names['scope_of_work'];  
               }  

              if ($_FILES['img_pro']['size'] != 0)
               {
                $img_pro=file_upload_3();
               }
             else
               {
                $img_pro=$get_names['proposal'];  
               }   
               
              $lead_by = $user->get_current_user()['first_name']." ".$user->get_current_user()['last_name'];
              $sales_person_id = $user->get_current_user()['id'];

              $lead_data = array(

                  'agreement_status'           => $_POST['agreement_status'],
                  'scope_of_work'              => $scope_of_work,
                  'agreement'                  => $agreement_name,
                  'proposal'                   => $img_pro,
                  'signing_date'               => $_POST['agreement_date'],
                  'else_cost_set'              => $_POST['else_cost']
            

                  );
            $db->update_values($lead_data, "leads"); 

    }

    public function update_agreement()
    {
      global $db,$user;

      $agreement_data = array(
            'team_assigned'                 => $_POST['team_assigned'],
            'execution_timeline'            => $_POST['completion_date']
            
             ); 
      $db->update_values($agreement_data, "leads");              

    }          

    public function update_execution()
    {
      global $db,$user;

      function upload_letter()
          
          {
          global $db,$user;
          if ($user->is_login_admin())
            {
            $targetfolder = "/img/files/";
            }
                  
                  
            if ($user->is_login_user())
            {
              $targetfolder = "admin/img/files/";
            }

                  $targetfolder = $targetfolder . basename( $_FILES['job_com_letter']['name']) ;
       
                  if(move_uploaded_file($_FILES['job_com_letter']['tmp_name'], $targetfolder))
       
                  {
       
                  //echo "The file ". basename( $_FILES['fileToUpload']['name']). " is uploaded";
                  return $_FILES['job_com_letter']['name'];
                  }

                
            }

            /*Get Existing Records*/ 
            $get_names=$db->fetch_single_row('SELECT * FROM '.PREFIX.'leads WHERE id='.$_GET['id']);

            if ($_FILES['job_com_letter']['size'] != 0)
               {
                $job_com_letter_neme=upload_letter();
               }
            else
              {
                $job_com_letter_neme=$get_names['job_completion_letter'];
              }   

            $execution_data = array(
            'communication_history'      => $_POST['commu_history'],
            'progress_percent'           => $_POST['progress_percent'],
            'completion_status'          => $_POST['completion_status'],
            'delayed_status_by_customer' => (int)$_POST['customer_delay'],
            'completion_date'            => $_POST['completion_date'],
            'job_completion_letter'      => $job_com_letter_neme,
            'completion_signed'          => $_POST['completion_signed']
            
            
             ); 
        
          echo "JUst texting...."  ;
          echo implode("-", $execution_data);
      $db->update_values($execution_data, "leads");              

    }
      
      

} //End Class
?>