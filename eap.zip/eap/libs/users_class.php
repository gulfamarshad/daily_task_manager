<?php
if (session_status() == PHP_SESSION_NONE) 
      {
            session_start();
      }
?>
<?php
  /**

   * User Class

   * @author Gulfam Khan

   * @copyright 2016

   */

class user {

private $main_user_name;


function __construct() {
       $this->ses_start();
       
   }

public function login_user($username, $password,$department=null)
	{
	    
	    $this->main_user_name=$username;
		global $sec;
		global $db;

	    /*Fetch existing info against of username by get_pass() function*/
	    $ret_pass = $this->get_pass()['password'];
	    $ret_access_level = $this->get_pass()['level_access'];
	    $ret_department = $this->get_pass()['department'];
	    $ret_active_level = $this->get_pass()['active'];
	    $ret_user_name    = $this->get_pass()['username']; 
	
		$ret_pass_1 = base64_decode($ret_pass);
		$publicKey = $sec->genRandString(32);
		$ret_pass_2 = $decryptedData = $sec->decrypt($ret_pass_1, $publicKey);
		$select_query = "SELECT username FROM ".PREFIX."users WHERE username='".$username."' AND '".$ret_pass_2."'='".$password."' AND department='".$department."'  AND level_access='".$ret_access_level."' AND active=1";
		$check = $db->run_query($select_query);
		
        if (mysql_num_rows($check) > 0 )
		
		{
			$_SESSION['USer_NAme'] = $username;
			$_SESSION['LEvel_ACcess'] = $ret_access_level;
			$login_date=date("Y/m/d");
		    $login_update = "UPDATE ".PREFIX."users SET last_active='".$login_date."' WHERE username='".$_SESSION['USer_NAme']."'"; 
			$db->run_query($login_update); 
		    if ($this->is_login_admin())
		        {
		        	$redirect_index = SITEURL."DRSA/";
		        }
		    if ($this->is_login_hod())
		        {
		        	$redirect_index = SITEURL."DRDH/";
		        }
		    if ($this->is_login_TeamMember())
		        {
		        	$redirect_index = SITEURL."DRTM/";
		        }    
		    global $custom_fun; $custom_fun->redirect_page($redirect_index);
			return true;
		}


	else 
	  {
	  	if ($ret_active_level == "0")
	   {
		echo '
		<div class="isa_info">
        <i class="fa fa-check"></i>
         
         <strong>Error!</strong> Inactive user; Please request your administrator for activation.
         </div>
         </div>
         ';	   	
	   }

	   if ($ret_department != $department)
	   {
		echo '
		<div class="isa_error">
         <strong>Error!</strong> You have selected wrong department! Please Select Your Own department.
         </div>
         </div>
         ';	   	
	   }
    
      if ($ret_user_name != $username OR $ret_pass_2 != $password)
      {
	    echo '
		<div id="s_msg">
		<div class="isa_error">
         <strong>Error!</strong> Incorrect User Name or Password.
        </div>
        </div>
         ';
	  	}
	  	return false;
	  	
	  }

	
	}	


public function ses_start()
  {
  /*	if (!isset($_SESSION))
  	{
        //session_save_path("E:/xampp/tmp/custom_temp");
  		//session_start();
  		echo "Session is not started";
  	}  */
    if (session_status() == PHP_SESSION_NONE) 
      {
            //session_set_cookie_params(3600);
            //ini_set('session.cookie_domain','.http://sales.pms.net.pk/');
            //session_set_cookie_params(0, '/', '.http://sales.pms.net.pk');
            //session_save_path('/tmp/check/');
            //session_id( 'mySessionId' );
            session_start();
            
            $_SESSION["favcolor"] = "green";
      		//echo "Session is started.";
      		return true;
      		
      }

    else
      {
      	//echo "Session is not started";
      	return false;
      	
      } 

  }


public function logout()
		{
			
			
			      unset($_SESSION['USer_NAme']);
			   	  unset($_SESSION['LEvel_ACcess']);
			   	  global $custom_fun; $custom_fun->redirect_page(SITEURL.'login/');
			   
			
		}

/* !for session time out
public function sess_time_out()
       {
       	if (isset($_SESSION['time_out']) && 
               (time() -   $_SESSION['time_out'] > 3600))
			{
				unset($_SESSION['USer_NAme']);
			}
       }

*/

public function is_login_hod()
		{
		   if (isset($_SESSION['USer_NAme']) && $_SESSION['LEvel_ACcess'] == '2') 
		  
		   {
		   		return true;
		   		
		   		
		   } 
			
		  else
		  {
				
				return false;
		  		
		  }			
		}


/*For checking is Team-member login*/
public function is_login_TeamMember()
		{
		   if (isset($_SESSION['USer_NAme']) && $_SESSION['LEvel_ACcess'] == '3') 
		  
		   {
		   		return true;
		   } 
			
		  else
		  {
				return false;
		  }			
		}

public function is_login_admin()
		{
		   if (isset($_SESSION['USer_NAme']) && $_SESSION['LEvel_ACcess'] == '1') 
		  
		   {
		   		
		   		return true;
		   		
		   		
		   } 
			
		  else
		  {
				
				return false;
		  		
		  }			
		}



public function get_pass()
		{
		global $db;
	    
	    $dup_username = $this->main_user_name;
		
	    $fetch_pass = "SELECT password, level_access, active ,department,username FROM ".PREFIX."users WHERE username ='".$dup_username."'";
		$result = $db->run_query($fetch_pass);
		if (mysql_num_rows($result) > 0)
		                           {
		                           $pass_value = $db->fetch_single_row($fetch_pass);
		                           return $pass_value;
		                            }
		else
		 {
		 	//header('location: login.php');
		 	

		 }
		}


public function register_user()
		{
			 
		
        global $sec,$db;
        $dup_email=$_POST['email'];
        $query_dup = "SELECT username FROM ".PREFIX."users WHERE username = '$dup_email'";
        $run_dup = $db->run_query($query_dup);

        if (mysql_num_rows($run_dup) > 0) {
	
	    echo '
		<div id="s_msg" style="margin-top:100px; width:400px;">
		               
		 <div class="alert alert-error">
         <strong>Error!</strong> Unable to register this user is already existngs.
         </div>
         </div>
         ';
	    global $custom_fun; $custom_fun->redirect_page('user_reg.php');
         exit();
	                                   }

        else {
        $enc_pw = $_POST['p_w']; 
		$publicKey = $sec->genRandString(32);
		$encryptedData = $sec->encrypt($enc_pw, $publicKey);
		$final_enc_pw =base64_encode($encryptedData) ;
		$final_enc_pw;
		$path_add =	$this->img_upload();
        
        $data = array(

			  		 'first_name'    => $_POST['first_name'],

					 'last_name'     =>  $_POST['last_name'],
		             
		             'department'    =>  $_POST['dep_name'],
					 
					 'img_path'      => $path_add, 

					 'level_access'  => $_POST['ac_level'], 
					 
					 'active'        => $_POST['act_status'],  
					 
					 'username'      => $_POST['email'],

					 'email'         => $_POST['email'],

					 'password'      => $final_enc_pw,
					 
					 'dialing_code'  => $_POST['d_code'],

					 'phone'         => $_POST['phone_no'],

					 'country'       => $_POST['country'],

					 'city'          => $_POST['city'] 

			  );
   	      
         /*
         $columns = implode(", ",array_keys($data));
         $escaped_values = array_map('mysql_real_escape_string', array_values($data));
         $values  = implode("', '", $escaped_values);
         $sql = "INSERT INTO ".PREFIX."users (".$columns.")"."VALUES('".$values."')";
		 $check_run = $db->run_query($sql);
		 */
		
		$db->insert_values($data, "users");
		/*
		if ($check_run)
		    {
		echo '
		<div id="s_msg" style="margin-top:100px; width:400px;">
		               
		 <div class="alert alert-error">
         <strong>Success!</strong> New user has been registered.
         </div>
         </div>
         ';
		    }
		*/
		}  
		
		}

public function img_upload()
		
		{
			if ($this->is_login_admin())
			{
			$targetfolder = UPLOAD_DIR;
 			}
            
            
 			if (!$this->is_login_admin())
 			{
 				$targetfolder = UPLOAD_DIR;
 			}

            $file_name = time().$_FILES['fileToUpload']['name']; 
            $targetfolder = $targetfolder . basename($file_name) ;
 
            if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $targetfolder))
 
            {
            return $file_name;
            }

          
		}


public function show_img()
		{
		 
	     global $db;
	     
	     $dup_username = $_SESSION['USer_NAme'];
        
         $fetch_user = "SELECT first_name, img_path FROM ".PREFIX."users WHERE username ='".$dup_username."' ";
		 $result_user = $db->run_query($fetch_user);
		 $user_value = mysql_fetch_array($result_user,MYSQL_ASSOC);
		 $final_user_value = $user_value['img_path']; 

		 $path = SITEURL."images/users/".$final_user_value;
		 
		 echo '
		 <img src="' .$path. '" alt="" width="25" height="25">
         <span class="username">'.$user_value['first_name'].'</span> ';
		}

public function show_users()
		{
		  
		 global $db;
		 
         if ($this->is_login_admin())
			 {
			  $users_fetch_query = "SELECT * FROM ".PREFIX."users order by id"; 
			  $redirect_edit     = SITEURL.'DRSA/add_users/';
			  $redirect_active   = SITEURL.'DRSA/manage_users/';
			 }

		 if ($this->is_login_hod())
			 {
			  $users_fetch_query = "SELECT * FROM ".PREFIX."users WHERE level_access = 3  AND department = ".$this->get_current_user()['department']." order by id"; 
			  $redirect_edit     = SITEURL.'DRDH/add_members/'; 
			  $redirect_active   = SITEURL.'DRDH/manage_members/';
			 }	 
		 
		 $res = $db->fetch_all($users_fetch_query);
		 $sr = null;
		 foreach ($res as $key => $value) {
			$sr++;
		 if ($value['active'] == '1')
		    {
		       $img_active = "<i class='icon-eye-open'></i> Active";
		 	}	

		 else
		    {
		       $img_active = "<i class='icon-eye-close'></i> Inactive";
		    }	

		 	echo 
		 	"<tr><td clas='hidden-phone'>".$sr."</td>".
		 	"<td clas='hidden-phone'>".$value['first_name']." ".$value['last_name']."</td>".
		 	"<td>".$value['email']."</td>".
		 	"<td>".$value['level_access']."</td>".
		 	"<td>".$value['last_active']."</td> ".
		 	"<td>".$img_active."</td>".
		 	
		 	'<td>
             <a class="" href="'.$redirect_active.'?id='.$value['id'].' &action=active"><img src="images/Button-Blank-Yellow-icon.png"/></a>
             <a class="js-open-modal" href="'.$redirect_edit.'?HFLsohf=89e6 &id='.base64_encode($value['id']).'"><img src="images/edit-icon.png"/></a>
             <a class="js-open-modal" href="#" data-modal-id="popup'.$value['id'].'"><img src="images/yellow-cross-icon.png"/></a>  
            </td> 
            </tr>';
		 	 }	 
		}

public function update_user()
       {
       	 global $db;
       	 if (!empty($_POST['p_w']))	
       	    {
       	      global $sec;
		      $enc_pw = $_POST['p_w']; 
		      $publicKey = $sec->genRandString(32);
		      $encryptedData = $sec->encrypt($enc_pw, $publicKey);
		      $final_enc_pw =base64_encode($encryptedData) ;
       	      $password_value = $final_enc_pw;
       	      
       	    }
       	 if (empty($_POST['p_w']))
       	   {
       	 	  $password_value = $this->get_user()['password'];  	
       	   }

       	 

       	 $data = array(

			  		 'first_name'    => $_POST['first_name'],

					 'last_name'     => $_POST['last_name'],

					 'level_access'  => $_POST['ac_level'], 

					 'department'    => $_POST['dep_name'], 

					 'active'        => $_POST['act_status'],
					  
					 'username'      => $_POST['email'],

					 'email'         => $_POST['email'],

					 'password'      => $password_value,
					 
					 'dialing_code'  => $_POST['d_code'],

					 'phone'         => $_POST['phone_no'],

					 'country'       => $_POST['country'],

					 'city'          => $_POST['city'] 

			  );
      
      
      				$db->update_values($data,"users");
      				/*
                      $up_first_name    =$data['first_name'];  
                      $up_last_name     =$data['last_name'];
                      $up_level_access  =$data['level_access'];
                      $up_department    =$data['department'];
                      $up_active        =$data['active'];
                      $up_username      =$data['username'];
                      $up_password      =$data['password'];
                      $up_email         =$data['email'];
                      $up_dialing_code  =$data['dialing_code'];
                      $up_phone         =$data['phone'];
                      $up_country       =$data['country'];
                      $up_city          =$data['city'];
                      
                      $update_query = 
                      "
                      UPDATE " .PREFIX."users ".
                      "SET 
                      first_name='".$up_first_name."', ".
                      "last_name='".$up_last_name."', ".
                      "level_access='".$up_level_access."', ".
                      "department='".$up_department."', ".
                      "active='".$up_active."', ".
                      "username='".$up_username."', ".
                      "password='".$up_password."', ".
                      "email='".$up_email."', ".
                      "dialing_code='".$up_dialing_code."',".
                      "phone='".$up_phone."', ".
                      "country='".$up_country."', ".
                      "city='".$up_city."' WHERE id=".base64_decode($_GET['id']);
                       global $db;
                       $db->run_query($update_query);
                       echo '
		               
		               <div id="s_msg" style="width:100%;" align="center">
		               
		               <div class="alert alert-success">
         
                       <strong>Success!</strong>User has been updated.
                       </div>
                       
                       </div>

                       '; 
                     */
       }

public function get_user()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."users WHERE id =".base64_decode($_GET['id']); 
         return $fetched = $db->fetch_single_row($users_fetch_query);
        }






public function get_current_user()
        {
         global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."users WHERE username ='".$_SESSION['USer_NAme']."'"; 
         return $fetched = $db->fetch_single_row($users_fetch_query);	
        }

public function get_other_user()
        {
         global $db;
		 if (!isset($_GET['id']))
		 {
		 	$deep = $this->get_current_user()['id'];
		 }
		 else
		 {
		 	$deep = $_GET['id'];	
		 }
		 $users_fetch_query = "SELECT * FROM ".PREFIX."users WHERE id ='".$deep."'"; 
         return $fetched = $db->fetch_single_row($users_fetch_query);	
        }




public function change_password($old_pass, $new_pass)
	   {
	   	
	   	  global $sec,$db;
	      $ret_pass = $this->get_current_user()['password'];
		  $ret_pass_1 = base64_decode($ret_pass);
		  $publicKey = $sec->genRandString(32);
          $existing_password = $decryptedData = $sec->decrypt($ret_pass_1, $publicKey);
		  
		 //if ( !strcmp($old_pass, $existing_password) )	// Only run when passwords are different
		 if ( $old_pass == $existing_password )	// Only run when passwords are different 	 
		  	 { //Main if
		  	 	//echo "<p style='color: white; margin-top:50px;'>"."Matched"."<p>";
		  	 	if (!empty($_POST['new_pass']))
		  	 	   { //first inner if
		             $publicKey = $sec->genRandString(32);
	                 $encryptedData = $sec->encrypt($new_pass, $publicKey);
	                 $final_pass_up = base64_encode($encryptedData);
	                 $fetch_specific_id="SELECT id FROM ".PREFIX."users WHERE username='".$_SESSION['USer_NAme']."'";
	                 $breif_id=$db->fetch_single_row($fetch_specific_id)['id']."</p>";
	                 $update_final_pass_up = "UPDATE ".PREFIX."users SET password= '".$final_pass_up."'"." WHERE id= '".$breif_id."'";
	                 $run = $db->run_query($update_final_pass_up);
	                 
	                 
	                   if ($run = $db->run_query($update_final_pass_up))
	                     {
	                   		//echo "<p style='color: white; margin-top:50px;'>"."Wrong password"."<p>";
	                   	          
	                   	          echo '
		                          <div class="isa_success" align="center">
                                  <strong>Success!</strong>Now password has been changed.
                                  </div>
                                   ';
	                     }
	                  
	                  
	               
		  	 	   		
		  	 	   } //end first inner if
		  	 		  
	   	  
	   	  


	   } // End main if

       elseif ( $existing_password != $old_pass && empty($_POST['new_pass']))
	                     {
	                     	echo '
		                          <div class="isa_error" align="center">
                                  <strong>Error!</strong>Old password did not match, Please try again.
                                  </div>
                                   '; 
	                     }
       elseif ( $existing_password != $old_pass && !empty($_POST['new_pass']))
	                     {
	                     	echo '
		                          <div class="isa_error" align="center">
                                  <strong>Error!</strong>Old password did not match, Please try again.
                                  </div>
                                   '; 
	                     }


}

public function active_stuff($table,$col)
	{
		
		global $db;
	    $set_active = $db->fetch_single_row("SELECT ".$col." FROM ".PREFIX.$table." WHERE id=".$_GET['id']);
		
		if ($set_active[$col] == "1")
		 {

		   $SQL = "UPDATE ".PREFIX.$table." SET ".$col."=0 WHERE id =".$_GET['id'];
		   $db->run_query($SQL);
	       global $custom_fun; $custom_fun->redirect_page($_SERVER['HTTP_REFERER']);
	       #echo "<script>setTimeout(\"location.href = '".$_SERVER['HTTP_REFERER']."';\",2500);</script>";
		 
		 }	
		 else
		 {
		    $SQL = "UPDATE ".PREFIX.$table." SET ".$col."=1 WHERE id =".$_GET['id'];
		    $db->run_query($SQL);
		 	global $custom_fun; $custom_fun->redirect_page($_SERVER['HTTP_REFERER']);
		 	
		 }
	}

public function delete_stuff($table)   
    {
    global $db;
    $id = $_GET['id'];
    $del_query = "DELETE FROM ".PREFIX.$table." WHERE id=".$id;
    $db->run_query($del_query);	
    global $custom_fun; $custom_fun->redirect_page($_SERVER['HTTP_REFERER']);
    }

public function update_profile_info()
	{
		
		
       	 if ($_FILES['fileToUpload']['size'] != 0)
       	 {
       	    $path_add =	$this->img_upload();
       	 }

       	 elseif ($_FILES['fileToUpload']['size'] == 0)
       	 {	
       	 	$path_add = $this->get_current_user()['img_path'];
       	 }

       	 $data = array(

			  		 'first_name'    => $_POST['first_name'],

					 'last_name'     =>  $_POST['last_name'],

					 'img_path'      => $path_add, 

					 //'username'      => $_POST['email'],

					 //'email'         => $_POST['email'],

					 'dialing_code'  => $_POST['d_code'],

					 'phone'         => $_POST['phone_no'],

					 'country'       => $_POST['country'],

					 'city'          => $_POST['city'] 

			  );
      
      
      				
                      $up_first_name    =$data['first_name'];  
                      $up_last_name     =$data['last_name'];
                      
                      $up_dialing_code  =$data['dialing_code'];
                      $up_phone         =$data['phone'];
                      $up_img_path      =$data['img_path'];
                      $up_country       =$data['country'];
                      $up_city          =$data['city'];
                      
                      $update_query = 
                      "
                      UPDATE " .PREFIX."users ".
                      "SET 
                      first_name='".$up_first_name."', ".
                      "last_name='".$up_last_name."', ".
                      "dialing_code='".$up_dialing_code."',".
                      "img_path='".$up_img_path."',".
                      "phone='".$up_phone."', ".
                      "country='".$up_country."', ".
                      "city='".$up_city."' WHERE id=".$this->get_current_user()['id'];
                       
                       global $db;
                       if ($db->run_query($update_query))
                          {
                       echo '
		               <div class="isa_success" align="center">
                       <strong>Success!</strong>Profile info has been updated.
                       </div>
                       '; 
                       }
	}

public function send_msg() 
    {
    	
    	date_default_timezone_set('Asia/Karachi');
    	
        //$current_dt = date('l jS F Y h:i:s A');
        $current_dt = date('Y-m-d h:i:s A');
    	
    	$id = $this->get_current_user()['id'];
    	$oth_id = $this->get_other_user()['id'];
    	

    	if(!empty($_POST['msg_body']))
    	{
    		global $db;
 			$msg_data = array(

			  		 'u_id'          => $id,

			  		 'date_time'   => $current_dt,   
					 
					 'message'     => $_POST['msg_body'],

					 'sender_id'   => $id,

					 'rec_id'      => $oth_id 

					         );
   	      
         $columns = implode(", ",array_keys($msg_data));
         $escaped_values = array_map('mysql_real_escape_string', array_values($msg_data));
         $values  = implode("', '", $escaped_values);
         $sql = "INSERT INTO ".PREFIX."messages (".$columns.")"."VALUES('".$values."')";
		 $check_run = $db->run_query($sql);
		 
 			
 			//Previous
 			//$msg_text = $_POST['msg_body'];
    		//$msg_query = "INSERT INTO ".PREFIX."messages (message) VALUES('".$msg_text."')";
    		//$db->run_query($msg_query);
    	}
    }


public function show_chat()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."users order by id"; 
		 $res = $db->fetch_all($users_fetch_query);
		 foreach ($res as $key => $value) {
		 	 	//echo implode(",", $value);
		 	echo 
		 	    '
		 	    <li><a href="chat.php?id='.$value['id'].'" ><i class="icon-user"></i> '.$value['first_name'].' '.$value['last_name'].'</a></li>
		 	    
		 	    ';
		 	 }	 
		}

public function show_msg_noti()
		{
         
         global $db;
         $noti_fetch_query = "SELECT * FROM ".PREFIX."messages WHERE rec_id=".$this->get_current_user()['id']; 
		 $run_noti_fetch   = $db->run_query($noti_fetch_query);
		 echo mysql_num_rows($run_noti_fetch);


		}

public function show_noti_messages()
       {
    			  if($this->is_login_admin())
    			  {
    			  	$link=  "manage_users.php?id=";
    			  }

    			  else
    			  {
    			    $link=  "chat.php?id=";	
    			  }


    			  global $db;
    			  $fetch_user_info =  "SELECT * FROM ".PREFIX."users WHERE id=";
    		      $noti_fetch_query_messages = "SELECT u_id, date_time, message, sender_id, rec_id FROM ".PREFIX."messages WHERE rec_id=".$this->get_current_user()['id']." GROUP BY u_id DESC "; 
    			  $noti_fetch_query_messages_run = $db->fetch_all($noti_fetch_query_messages);

 				  foreach ($noti_fetch_query_messages_run as $key => $value_messages) {
 				  
 				  echo '
       	          <li>
                  <a href="'.$link.$value_messages['sender_id'].'">
                  <span class="photo"><img src="'.SHOW_IMG.$db->fetch_single_row($fetch_user_info.$value_messages['sender_id'])['img_path'].'" alt="avatar" /></span>
                  <span class="subject">
                  <span class="from">'.$db->fetch_single_row($fetch_user_info.$value_messages['sender_id'])['first_name'].' '.$db->fetch_single_row($fetch_user_info.$value_messages['sender_id'])['last_name'].'</span>
                  <span class="time">'.substr($value_messages['date_time'], 0, 10).'</span>
                  </span>
                  <span class="message">'.$value_messages['message'].
                      
                  '</span>
                  </a>
                  </li>';

                  }
       }


public function send_mail()
       
       {
	   	global $custom_fun;
	   	$final_msg_body = $_POST['message_body'];

	   	if ($_FILES['my_file']['size'] != 0)
	   	 {
	   	 $data_mail = array(

			  		 'to'            =>  $_POST['send_add'],

					 'subject'       =>  $_POST['send_subject'],

					 'message_body'  =>  $_POST['message_body'] 

					 
			  );
	   
 	 $from_email        = 'info@pms.net.pk'; //sender email
     $recipient_email   =  rtrim($data_mail['to'], " ," ); //recipient email rtrim for removing last ","
    
     $subject           =  $data_mail['subject'] ; //subject of email
     $message           =  strip_tags($data_mail['message_body']); //message body
    
    //get file details we need
    $file_tmp_name    = $_FILES['my_file']['tmp_name'];
    $file_name        = $_FILES['my_file']['name'];
    $file_size        = $_FILES['my_file']['size'];
    $file_type        = $_FILES['my_file']['type'];
    $file_error       = $_FILES['my_file']['error'];
    
    $user_email = filter_var($_POST["message_body"], FILTER_SANITIZE_EMAIL);
    
    if($file_error>0)
    {
        die('upload error');
    } 
    //read from the uploaded file & base64_encode content for the mail
    $handle = fopen($file_tmp_name, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $encoded_content = chunk_split(base64_encode($content));


        $boundary = md5("sanwebe"); 
        //header
        $headers = "MIME-Version: 1.0\r\n";

        $headers .= "From:".$from_email."\r\n"; 
        $headers .= "Reply-To: ".$user_email."" . "\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n";
        
        
        //plain text 
        $body = "--$boundary\r\n";
       
        $body .= "Content-Type: text/plain; charset=ISO-8859-1\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
        $body .= chunk_split(base64_encode($message));
        $body .= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
        
        //attachment
        $body .= "--$boundary\r\n";
        $body .="Content-Type: $file_type; name=".$file_name."\r\n";
        $body .="Content-Disposition: attachment; filename=".$file_name."\r\n";
        $body .="Content-Transfer-Encoding: base64\r\n";
        $body .="X-Attachment-Id: ".rand(1000,99999)."\r\n\r\n"; 
        $body .= $encoded_content; 
        
    
    $sentMail = @mail($recipient_email, $subject, $body, $headers);
    if($sentMail) //output success or failure messages
    {       
        //die('Thank you for your email...file attached');
        echo '
		               
		               <div id="s_msg" style="margin-top:100px; width:400px;">
		               
		               <div class="alert alert-success">
         
                       <strong>Success!</strong>Email has sent successfully.
                       </div>
                       
                       </div>

                       '; 
    }else{
        die('Could not send mail! Please check your PHP mail configuration.');  
    }

    }


    else
    {
	  
	  	   	
	   	 
	   	 $data_mail = array(

			  		 'to'            =>  $_POST['send_add'],

					 'subject'       =>  $_POST['send_subject'],

					 'message_body'  =>  $_POST['message_body'] 

					 
			  );
	   
 	 $from_email        = 'info@pms.net.pk'; //sender email
     $recipient_email   =  rtrim($data_mail['to'], " ," ); //recipient email rtrim for removing last ","
    
     $subject           =  $data_mail['subject'] ; //subject of email
     $message           =  $data_mail['message_body']; //message body
    
    
    
    $user_email = filter_var($_POST["message_body"], FILTER_SANITIZE_EMAIL);
    
    
    //read from the uploaded file & base64_encode content for the mail
    


        $boundary = md5("sanwebe"); 
        //header
        $headers = "MIME-Version: 1.0\r\n"; 
        $headers .= "From:".$from_email."\r\n"; 
        $headers .= "Reply-To: ".$user_email."" . "\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n"; 
         
        //plain text 
        $body = "--$boundary\r\n";
        $body .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
        $body .= chunk_split(base64_encode($message));
        
        
        
    
    $sentMail = @mail($recipient_email, $subject, $body, $headers);
    
    if($sentMail) //output success or failure messages
    {       
        //die('Thank you for your email');
        echo '
		               
		               <div id="s_msg" style="margin-top:100px; width:400px;">
		               
		               <div class="alert alert-success">
         
                       <strong>Success!</strong>Email has sent successfully.
                       </div>
                       
                       </div>

                       '; 

    }else{
        die('Could not send mail! Please check your PHP mail configuration.');  
    }    	

    }   
    
   }   



public function show_products()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."products order by id"; 
		 $res = $db->fetch_all($users_fetch_query);
		 foreach ($res as $key => $value) {
		 	 	//echo implode(",", $value);
		 if ($value['status'] == '1')
		    {
		       $img_active = "<i class='icon-eye-open'></i> Active";
		 	}	

		 else
		    {
		       $img_active = "<i class='icon-eye-close'></i> Inactive";
		    }	

		 	echo 
		 	
		 	"<tr class='odd gradeX'><td clas='hidden-phone'>".$value['trans_code']."</td>".
		 	
		 	"<td clas='hidden-phone'>".$value['name_item']."</td>".
		 	"<td clas='hidden-phone'>".$value['category']."</td> ".
		 	"<td clas='hidden-phone'>".$value['type']."</td>".
		 	"<td clas='hidden-phone'>".$value['user']."</td>".
		 	"<td clas='hidden-phone'>".$img_active."</td>";
		 	

		 	if ($this->is_login_admin()) 
		 	{
		 echo '<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="#myModal_view'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-eye-open"></i> View</a></li>
                            <li><a href="add_product.php?id='.$value['id'].' &action=edit"><i class="icon-edit"></i> Edit</a></li>
                            <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                            <li><a href="manage_products.php?id='.$value['id'].' &action=active"><i class="icon-user"></i>Active/Inactive </a></li>
                            
                        </ul>
                </div>
            </td> 
            </tr>';
		 	 }
		 	 
		 	  else
		 	 {
		 	  echo '<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">';
                            
                            echo '<li><a href="#myModal_view'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-eye-open"></i> View</a></li>
                                 ';
                           
                    
                     echo   '   
                        </ul>
                </div>
            </td> 
            </tr>';	
            
		 	 }

		 	 }	 
		}





public function update_products_info()
	{
		
		
       	 
        $data = array(

			  		 'type'            => $_POST['type'],

					 'name_item'       => $_POST['pr_name'],

					 'category'        => $_POST['category'], 

					 'mu'              => $_POST['mu'],

					 'purchase_price'  => $_POST['purchase_price'],

					 'sales_price'     => $_POST['sales_price'],

					 'min'             => $_POST['min'],

					 'max'             => $_POST['max'],

					 'location'        => $_POST['location'],

					 'more'            => $_POST['more']

           			  );
      
      
      
                      $up_type            =$data['type'];  
                      $up_name_item       =$data['name_item'];
                      $up_category        =$data['category'];
                      $up_mu              =$data['mu'];
                      $up_purcahse_price  =$data['purchase_price'];
                      $up_sales_price     =$data['sales_price'];
                      $up_min             =$data['min'];
                      $up_max             =$data['max'];
                      $up_location        =$data['location'];
                      $up_more            =$data['more'];
                      
                      $update_query = 
                      "
                      UPDATE " .PREFIX."products ".
                      "SET 
                      type='".$up_type."', ".
                      "name_item='".$up_name_item."', ".
                      "category='".$up_category."',".
                      "mu='".$up_mu."',".
                      "purchase_price='".$up_purcahse_price."', ".
                      "sales_price='".$up_sales_price."', ".
                      "min='".$up_min."', ".
                      "max='".$up_max."', ".
                      "location='".$up_location."', ".
                      "more='".$up_more."' WHERE id=".$_GET['id'];
                       
                       global $db;
                       $db->run_query($update_query);
                       echo '
		               
		               <div id="s_msg" style="margin-top:100px; width:400px;">
		               
		               <div class="alert alert-success">
         
                       <strong>Success!</strong>Products info has been updated.
                       </div>
                       
                       </div>

                       '; 
	}



public function show_categories()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."category order by id"; 
		 $res = $db->fetch_all($users_fetch_query);
		 $sr_no = 1;
		 foreach ($res as $key => $value) {
		 	 	//echo implode(",", $value);
		 if ($value['status'] == '1')
		    {
		       $img_active = "<i class='icon-eye-open'></i> Active";
		 	}	

		 else
		    {
		       $img_active = "<i class='icon-eye-close'></i> Inactive";
		    }	

		 	echo 
		 	"<tr class='odd gradeX'><td clas='hidden-phone'>".$sr_no++."</td>".
		 	
		 	"<td clas='hidden-phone'>".$value['category']."</td>".
		 	"<td clas='hidden-phone'>".$value['user']."</td> ".
		 	"<td clas='hidden-phone'>".$value['post_date']."</td>".
		 	"<td clas='hidden-phone'>".$img_active."</td>".
		 	
		 	


		 	'<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="#mol_cate" role="button"  data-toggle="modal"><i class="icon-plus"></i> Add</a></li>
                            <li><a href="#myModal_edit'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-edit"></i> Edit</a></li>
                            <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                            <li><a href="manage_category.php?id='.$value['id'].' &action=active"><i class="icon-user"></i>Active/Inactive </a></li>
                            
                        </ul>
                </div>
            </td> 
            </tr>';
		 	 }	 
		}


public function show_mu()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."mu order by id"; 
		 $res = $db->fetch_all($users_fetch_query);
		 $sr_no = 1;
		 foreach ($res as $key => $value) {
		 	 	//echo implode(",", $value);
		 if ($value['status'] == '1')
		    {
		       $img_active = "<i class='icon-eye-open'></i> Active";
		 	}	

		 else
		    {
		       $img_active = "<i class='icon-eye-close'></i> Inactive";
		    }	

		 	echo 
		 	"<tr class='odd gradeX'><td clas='hidden-phone'>".$sr_no++."</td>".
		 	
		 	"<td clas='hidden-phone'>".$value['mu']."</td>".
		 	"<td clas='hidden-phone'>".$value['user']."</td> ".
		 	"<td clas='hidden-phone'>".$value['post_date']."</td>".
		 	"<td clas='hidden-phone'>".$img_active."</td>".
		 	
		 	


		 	'<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="#mol_mu" role="button"  data-toggle="modal"><i class="icon-plus"></i> Add</a></li>
                            <li><a href="#myModal_edit'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-edit"></i> Edit</a></li>
                            <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                            <li><a href="manage_mu.php?id='.$value['id'].' &action=active"><i class="icon-user"></i>Active/Inactive </a></li>
                            
                        </ul>
                </div>
            </td> 
            </tr>';
		 	 }	 
		}



public function show_customers()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."customers order by id"; 
		 $res = $db->fetch_all($users_fetch_query);
		 $sr_no = 1;
		 foreach ($res as $key => $value) {
	
		 if ($value['status'] == '1')
		    {
		       $img_active = "<i class='icon-eye-open'></i> Active";
		 	}	

		 else 
		    {
		       $img_active = "<i class='icon-eye-close'></i> Inactive";
		    }	
		 
		 if ($value['objection'] == '1')
		    {
		       $objection = "<i class='icon-exclamation-sign popovers'   data-trigger='hover' data-content='Objection By ".$value['obj_by']."' data-original-title='Objection' style='color:red;'></i> Objection";
		    }
		 else 
		    {
		       $objection = "<i class='icon-ban-circle popovers'   data-trigger='hover' data-content='No Objection ' data-original-title='Objection'></i>";
		    } 
		  
		 	echo 
		 	"<tr class='odd gradeX'><td clas='hidden-phone'>".$sr_no++."</td>".
		 	
		 	"<td clas='hidden-phone'>".$value['business_name']."</td>".
		 	"<td clas='hidden-phone'>".$value['contact_person']."</td> ".
		 	"<td clas='hidden-phone'>"."<a href='tel:".$value['mobile_no']."'>".$value['mobile_no']."</a>"."</td>".
		 	"<td clas='hidden-phone'>".$value['business_type']."</td>".
		 	"<td clas='hidden-phone'>".$value['city']."</td>".
		 	"<td clas='hidden-phone'>".$value['sales_person']."</td>".
		 	"<td clas='hidden-phone'>".$value['visit_date']."</td>".
		 	"<td clas='hidden-phone'>".$img_active."</td>".
		 	"<td clas='hidden-phone'>".$objection."</td>";
		 	
		 	
		 	if ($this->is_login_admin())	
		 	{
		 echo '<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="#myModal_view'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-eye-open"></i> View</a></li>
                            <li><a href="add_customer.php?id='.$value['id'].'&action=edit" role="button"  data-toggle="modal"><i class="icon-edit"></i> Edit</a></li>
                            <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                            <li><a href="manage_customers.php?id='.$value['id'].' &action=active"><i class="icon-user"></i> Active/Inactive </a></li>
                            <li><a href="manage_customers.php?id='.$value['id'].' &action=objection"><i class="icon-exclamation-sign"></i> Objection </a></li>
                            
                        </ul>
                </div>
            </td> 
            </tr>';
		 	 }

		 	 else
		 	 {
		 	  echo '<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">';
                            
                            if ($this->get_current_user()['id'] == $value['sales_person_id'])
                            {
                            echo '
                            	  
                            	  <li><a href="add_customer.php?id='.$value['id'].'&action=edit" role="button"  data-toggle="modal"><i class="icon-edit"></i> Edit</a></li>
                                  <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                                  <li><a href="manage_customers.php?id='.$value['id'].' &action=active"><i class="icon-user"></i> Active/Inactive </a></li>
                                 ';
                            }
                    echo    '
                            <li><a href="#myModal_view'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-eye-open"></i> View</a></li>
                            <li><a href="manage_customers.php?id='.$value['id'].' &action=objection"><i class="icon-exclamation-sign"></i> Objection </a></li>
                            
                        </ul>
                </div>
            </td> 
            </tr>';	
		 	 }


		 	 }	 
		}

		public function show_old_customers()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."old_customers order by id"; 
		 $res = $db->fetch_all($users_fetch_query);
		 $sr_no = 1;
		 foreach ($res as $key => $value) {
	
		 if ($value['status'] == '1')
		    {
		       $img_active = "<i class='icon-eye-open'></i> Active";
		 	}	

		 else 
		    {
		       $img_active = "<i class='icon-eye-close'></i> Inactive";
		    }	
		 
		 if ($value['objection'] == '1')
		    {
		       $objection = "<i class='icon-exclamation-sign popovers'   data-trigger='hover' data-content='Objection By ".$value['obj_by']."' data-original-title='Objection' style='color:red;'></i> Objection";
		    }
		 else 
		    {
		       $objection = "<i class='icon-ban-circle popovers'   data-trigger='hover' data-content='No Objection ' data-original-title='Objection'></i>";
		    } 
		  
		 	echo 
		 	"<tr class='odd gradeX'><td clas='hidden-phone'>".$sr_no++."</td>".
		 	
		 	"<td clas='hidden-phone'>".$value['business_name']."</td>".
		 	"<td clas='hidden-phone'>".$value['contact_person']."</td> ".
		 	"<td clas='hidden-phone'>"."<a href='tel:".$value['mobile_no']."'>".$value['mobile_no']."</a>"."</td>".
		 	"<td clas='hidden-phone'>".$value['business_type']."</td>".
		 	"<td clas='hidden-phone'>".$value['city']."</td>".
		 	"<td clas='hidden-phone'>".$value['sales_person']."</td>".
		 	"<td clas='hidden-phone'>".$value['visit_date']."</td>".
		 	"<td clas='hidden-phone'>".$img_active."</td>".
		 	"<td clas='hidden-phone'>".$objection."</td>";
		 	
		 	
		 	if ($this->is_login_admin())	
		 	{
		 echo '<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="#myModal_view'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-eye-open"></i> View</a></li>
                            <li><a href="add_old_customer.php?id='.$value['id'].'&action=edit" role="button"  data-toggle="modal"><i class="icon-edit"></i> Edit</a></li>
                            <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                            <li><a href="old_customers.php?id='.$value['id'].' &action=active"><i class="icon-user"></i> Active/Inactive </a></li>
                            <li><a href="old_customers.php?id='.$value['id'].' &action=objection"><i class="icon-exclamation-sign"></i> Objection </a></li>
                            
                        </ul>
                </div>
            </td> 
            </tr>';
		 	 }

		 	 else
		 	 {
		 	  echo '<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>
                        <ul class="dropdown-menu">';
                            
                            if ($this->get_current_user()['id'] == $value['sales_person_id'])
                            {
                            echo '
                            	  
                            	  <li><a href="add_customer.php?id='.$value['id'].'&action=edit" role="button"  data-toggle="modal"><i class="icon-edit"></i> Edit</a></li>
                                  <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                                  <li><a href="manage_customers.php?id='.$value['id'].' &action=active"><i class="icon-user"></i> Active/Inactive </a></li>
                                 ';
                            }
                    echo    '
                            <li><a href="#myModal_view'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-eye-open"></i> View</a></li>
                            <li><a href="manage_customers.php?id='.$value['id'].' &action=objection"><i class="icon-exclamation-sign"></i> Objection </a></li>
                            
                        </ul>
                </div>
            </td> 
            </tr>';	
		 	 }


		 	 }	 
		}




public function update_category_info()
	{
		date_default_timezone_set("Asia/Karachi");
        $u_info = $_SERVER['HTTP_USER_AGENT'];
        $u_ip   = $_SERVER["REMOTE_ADDR"];
        $p_time = date("h:i");
        $dateOP = date('m-d-Y');
        $c_u    = $this->get_current_user()['first_name'];

        $data = array(
                            'category'        => $_POST['update_cate'],
                            'user'            => $c_u,
                            'ip'              => $u_ip,
                            'user_info'       => $u_info,
                            'post_date'       => $dateOP,
                            'post_time'       => $p_time
                           );
      
      
      
                      
                      $up_category    =$data['category'];
                      $up_user        =$data['user'];
                      $up_ip          =$data['ip'];
                      $up_user_info   =$data['user_info'];
                      $up_post_date   =$data['post_date'];
                      $up_post_time   =$data['post_time'];
                  
                      
                      $update_query = 
                      "
                      UPDATE " .PREFIX."category ".
                      "SET 
                      category='".$up_category."', ".
                      "user='".$up_user."', ".
                      "ip='".$up_ip."',".
                      "user_info='".$up_user_info."',".
                      "post_date='".$up_post_date."', ".
                      "post_time='".$up_post_time."' WHERE id=".$_POST['spec_value'];
                       
                       global $db;
                       $db->run_query($update_query);
                       echo '
		               
		               <div id="s_msg" style="margin-top:100px; width:400px;">
		               
		               <div class="alert alert-success">
         
                       <strong>Success!</strong>Category info has been updated.
                       </div>
                       
                       </div>

                       '; 
	}


public function update_mu_info()
	{
		date_default_timezone_set("Asia/Karachi");
        $u_info = $_SERVER['HTTP_USER_AGENT'];
        $u_ip   = $_SERVER["REMOTE_ADDR"];
        $p_time = date("h:i");
        $dateOP = date('m-d-Y');
        $c_u    = $this->get_current_user()['first_name'];

        $data =      array(
                            'mu'              => $_POST['update_mu'],
                            'user'            => $c_u,
                            'ip'              => $u_ip,
                            'user_info'       => $u_info,
                            'post_date'       => $dateOP,
                            'post_time'       => $p_time
                           );
      
      
      
                      
                      $up_mu          =$data['mu'];
                      $up_user        =$data['user'];
                      $up_ip          =$data['ip'];
                      $up_user_info   =$data['user_info'];
                      $up_post_date   =$data['post_date'];
                      $up_post_time   =$data['post_time'];
                  
                      
                      $update_query = 
                      "
                      UPDATE " .PREFIX."mu ".
                      "SET 
                       mu='".$up_mu."', ".
                      "user='".$up_user."', ".
                      "ip='".$up_ip."',".
                      "user_info='".$up_user_info."',".
                      "post_date='".$up_post_date."', ".
                      "post_time='".$up_post_time."' WHERE id=".$_POST['spec_value'];
                       
                       global $db;
                       $db->run_query($update_query);
                       echo '
		               
		               <div id="s_msg" style="margin-top:100px; width:400px;">
		               
		               <div class="alert alert-success">
         
                       <strong>Success!</strong>MU info has been updated.
                       </div>
                       
                       </div>

                       '; 
	}


	public function update_customers_info()
	{
		
        $status_cu    = 1;
        $current_user = $this->get_current_user()['first_name'];

        $customer_data = array(
                     'code'            => $_POST['customer_code'],
                     'name'            => $_POST['cust_name'],
                     'business_name'   => $_POST['bus_name'],
                     'mobile_no'       => $_POST['mobile'],
                     'phone1'          => $_POST['phone1'],
                     'phone2'          => $_POST['phone2'],
                     'fax'             => $_POST['fax'],
                     'email'           => $_POST['email'],
                     'url'             => $_POST['url'],
                     'contact_mode'    => $_POST['con_sou'],
                     'business_type'   => $_POST['bus_type'],
                     'city'            => $_POST['city'],
                     'address1'        => $_POST['address'],
                     'contact_person'  => $_POST['contact_person'],
                     'notes'           => $_POST['notes'],
                     'status'          => $status_cu
                     
                     

                              );
      
      
      
                      
                      $up_code           =$customer_data['code'];
                      $up_name           =$customer_data['name'];
                      $up_business_name  =$customer_data['business_name'];
                      $up_mobile_no      =$customer_data['mobile_no'];
                      $up_phone1         =$customer_data['phone1'];
                      $up_phone2         =$customer_data['phone2'];
                      $up_fax            =$customer_data['fax'];
                      $up_email          =$customer_data['email'];
                      $up_url            =$customer_data['url'];
                      $up_contact_mode   =$customer_data['contact_mode'];
                      $up_business_type  =$customer_data['business_type'];
                      $up_city           =$customer_data['city'];
                      $up_address1       =$customer_data['address1'];
                      $up_contact_person =$customer_data['contact_person'];
                      $up_notes          =$customer_data['notes'];
                      $up_status         =$customer_data['status'];
                      
                      
                  
                      
                      $update_query = 
                      "
                      UPDATE " .PREFIX."customers ".
                      "SET 
                       code='".$up_code."', ".
                      "name='".$up_name."', ".
                      "business_name='".$up_business_name."',".
                      "mobile_no='".$up_mobile_no."',".
                      "phone1='".$up_phone1."', ".
                      "phone2='".$up_phone2."', ".
                      "fax='".$up_fax."',".
                      "email='".$up_email."',".
                      "url='".$up_url."', ".
                      "contact_mode='".$up_contact_mode."', ".
                      "business_type='".$up_business_type."',".
                      "city='".$up_city."',".
                      "address1='".$up_address1."', ".
                      "contact_person='".$up_contact_person."', ".
                      "notes='".$up_notes."',".
                      "status='".$up_status."' WHERE id=".$_GET['id'];
                       
                       global $db;
                       if ($db->run_query($update_query))
                          {
                       		global $custom_fun; $custom_fun->redirect_page($_SERVER['REQUEST_URI']);   	
                          }
                       
                     }


 public function update_old_customers_info()
	{
		
        $status_cu    = 1;
        $current_user = $this->get_current_user()['first_name'];

        $customer_data = array(
                     'code'            => $_POST['customer_code'],
                     'name'            => $_POST['cust_name'],
                     'business_name'   => $_POST['bus_name'],
                     'mobile_no'       => $_POST['mobile'],
                     'phone1'          => $_POST['phone1'],
                     'phone2'          => $_POST['phone2'],
                     'fax'             => $_POST['fax'],
                     'email'           => $_POST['email'],
                     'assign'          => $_POST['reassigned'],
                     'url'             => $_POST['url'],
                     'contact_mode'    => $_POST['con_sou'],
                     'business_type'   => $_POST['bus_type'],
                     'city'            => $_POST['city'],
                     'address1'        => $_POST['address'],
                     'contact_person'  => $_POST['contact_person'],
                     'notes'           => $_POST['notes'],
                     'status'          => $status_cu
                     
                     

                              );
      
      
      
                      
                      $up_code           =$customer_data['code'];
                      $up_name           =$customer_data['name'];
                      $up_business_name  =$customer_data['business_name'];
                      $up_mobile_no      =$customer_data['mobile_no'];
                      $up_phone1         =$customer_data['phone1'];
                      $up_phone2         =$customer_data['phone2'];
                      $up_fax            =$customer_data['fax'];
                      $up_email          =$customer_data['email'];
                      $up_url            =$customer_data['url'];
                      $up_contact_mode   =$customer_data['contact_mode'];
                      $up_business_type  =$customer_data['business_type'];
                      $up_city           =$customer_data['city'];
                      $up_address1       =$customer_data['address1'];
                      $up_contact_person =$customer_data['contact_person'];
                      $up_notes          =$customer_data['notes'];
                      $up_status         =$customer_data['status'];
                      $up_assign	     =$customer_data['assign'];
                      
                      
                      
                  
                      
                      $update_query = 
                      "
                      UPDATE " .PREFIX."old_customers ".
                      "SET 
                       code='".$up_code."', ".
                      "name='".$up_name."', ".
                      "business_name='".$up_business_name."',".
                      "mobile_no='".$up_mobile_no."',".
                      "phone1='".$up_phone1."', ".
                      "phone2='".$up_phone2."', ".
                      "fax='".$up_fax."',".
                      "email='".$up_email."',".
                      "url='".$up_url."', ".
                      "contact_mode='".$up_contact_mode."', ".
                      "business_type='".$up_business_type."',".
                      "city='".$up_city."',".
                      "address1='".$up_address1."', ".
                      "contact_person='".$up_contact_person."', ".
                      "assign='".$up_assign."',".
                    
                      "notes='".$up_notes."',".
                      "status='".$up_status."' WHERE id=".$_GET['id'];
                       
                       global $db;
                       if ($db->run_query($update_query))
                          {
                       		$sales_person_new = $_POST['reassigned'];
                          	$fetched_s_p = $db->fetch_single_row("SELECT first_name, last_name FROM ".PREFIX."users WHERE id = ".$sales_person_new);
                      
                       		$new_customer_data = array(
							'code'            => $_POST['from_old'],
							'name'            => $_POST['cust_name'],
							'business_name'   => $_POST['bus_name'],
							'mobile_no'       => $_POST['mobile'],
							'phone1'          => $_POST['phone1'],
							'phone2'          => $_POST['phone2'],
							'fax'             => $_POST['fax'],
							'email'           => $_POST['email'],
							'url'             => $_POST['url'],
							'contact_mode'    => $_POST['con_sou'],
							'business_type'   => $_POST['bus_type'],
							'city'            => $_POST['city'],
							'address1'        => $_POST['address'],
							'contact_person'  => $_POST['contact_person'],
							'notes'           => $_POST['notes'],
							'status'          => $status_cu,
							'sales_person'    => $fetched_s_p['first_name']." ".$fetched_s_p['last_name'],
							'sales_person_id' => $_POST['reassigned'],
							'visit_date'      => date('Y-m-d')

							                  );

							if(!empty($_POST['reassigned']))
							{
							$db->insert_values($new_customer_data,"customers");
						    }

                       		//global $custom_fun; $custom_fun->redirect_page($_SERVER['REQUEST_URI']);   	
                          }
                       
                     
                       
	}







public function show_survey()
		{
		  
		 global $db;
		 $users_fetch_query = "SELECT * FROM ".PREFIX."survey order by id"; 
		 $res = $db->fetch_all($users_fetch_query);
		 $sr_no = 1;
		 foreach ($res as $key => $value) {
		 	 	//echo implode(",", $value);
		 if ($value['status'] == '1')
		    {
		       $img_active = "<i class='icon-eye-open'></i> Completed";
		 	}	

		elseif ($value['status'] == '2')
		    {
		       $img_active = "<i class='icon-eye-open'></i> In Progress";
		 	}	 	
		 
		 else
		    {
		       $img_active = "<i class='icon-eye-close'></i> Canceled";
		    }	

		 if ($value['file_name'] == "")
		 	 {
		 	 	$link = "#";
		 	 }
		else 
		    {
		    	$link="http://pms.net.pk/sales//admin/img/files/".$value['file_name'];
		    }	
		 	
		 	echo 
		 	"<tr class='odd gradeX'><td clas='hidden-phone'>".$sr_no++."</td>".
		 	
		 	"<td clas='hidden-phone'>".$value['survey_date']."</td>".
		 	"<td clas='hidden-phone'>".$value['customer_name']."</td>".
		 	"<td clas='hidden-phone'>".$value['lead_by']."</td> ".
		 	//"<td clas='hidden-phone'>".'<a href="#myModal_view_file'.$value['id'].'" role="button"  data-toggle="modal">View file</a>'."</td> ".
		 	"<td clas='hidden-phone'>"."<a href='".$link."'>View file</a>"."</td> ".
		 	"<td clas='hidden-phone'>".$img_active."</td>".
		 	
		 	


		 	'<td class="hidden-phone">
               <div class="btn-group">
                    <button class="btn btn-mini">Action</button>
                    <button data-toggle="dropdown" class="btn btn-mini dropdown-toggle b2"><span class="caret"></span></button>';
                        
                        if ($this->is_login_admin() OR $this->get_current_user()['id'] == $value['salesman_id'])	
                        {
                        echo '<ul class="dropdown-menu">
                              <li><a href="#myModal_view'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-eye-open"></i> View</a></li>
                              <li><a href="survey.php"><i class="icon-plus"></i> Add</a></li>
                              <li><a href="survey.php?id='.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-edit"></i> Edit</a></li>
                              <li><a href="#myModal'.$value['id'].'" role="button"  data-toggle="modal"><i class="icon-trash"></i> Delete</a></li>
                        </ul>';
             			}
             
             echo '</div>
            </td> 
            </tr>';
		 	 }	 
		}





} // class end


?>