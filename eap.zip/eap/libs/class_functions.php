<?php
 /**

   * Functions Class

   * @author Gulfam Khan

   * @copyright 2016

   */
class custom_functions

{


public function objection_stuff($table,$col)
  {
  
    global $db,$user;
      $current_user = $user->get_current_user()['first_name'];
      $set_active = $db->fetch_single_row("SELECT ".$col." FROM ".PREFIX.$table." WHERE id=".$_GET['id']);
    
    if ($set_active[$col] == "1")
     {
       if ($user->is_login_admin())
       {
       $SQL = "UPDATE ".PREFIX.$table." SET ".$col."=0, obj_by='".""."' WHERE id =".$_GET['id'];
       $db->run_query($SQL);
       global $custom_fun; $custom_fun->redirect_page($_SERVER['HTTP_REFERER']);
       }
       else
       {
        //header('Location: ' . $_SERVER['HTTP_REFERER']);
        //echo "<script>setTimeout(\"location.href = '".$_SERVER['HTTP_REFERER']."';\",2500);</script>";
        global $custom_fun; $custom_fun->redirect_page($_SERVER['HTTP_REFERER']);

        echo '
                   
                   <div id="s_msg" style="margin-top:100px; width:400px;">
                   
                   <div class="alert alert-error">
         
                       <strong>Error!</strong>Only admin remove this objection.
                       </div>
                       
                       </div>

                       '; 
                       
       }
     }  
     else
     {
        $SQL = "UPDATE ".PREFIX.$table." SET ".$col."=1, obj_by='".$current_user."' WHERE id =".$_GET['id'];
        $db->run_query($SQL);
      global $custom_fun; $custom_fun->redirect_page($_SERVER['HTTP_REFERER']);
      
     }
  }


public function update_config()
    {
      
      global $user,$db;

      
    function upload_logo()  

        {
        define("LOGO_PATH", "img/");
        global $user,$db;

      if ($user->is_login_admin())
      {
      $targetfolder = LOGO_PATH;
      }
            
            
      if ($user->is_login_user())
      {
        $targetfolder = "admin/".UPLOAD_DIR;
      }

            $targetfolder = $targetfolder.basename(time().$_FILES['fileToUpload']['name']) ;
 
            if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $targetfolder))
 
            {
            return time().$_FILES['fileToUpload']['name'];
            }

          }

        $uploaded_logo = upload_logo(); //Call a function within another function
        
        
         if ($_FILES['fileToUpload']['size'] == 0)
            {
                $fetch_data_sql  = "SELECT * FROM ".PREFIX."config"; 
                $result_fetch    = $db->fetch_single_row($fetch_data_sql);
                $f_logo_img      = $result_fetch['logo_img'];
                $img_name        = $f_logo_img;
            }

         if ($_FILES['fileToUpload']['size'] != 0)   
           {
                $img_name        = $uploaded_logo;
           }

        $config_data = array(

                         'page_title' => $_POST['page_title'] ,
                         'page_footer'=> $_POST['page_footer'] ,
                         'logo_img'   => $img_name

                          );

          

        $db->update_values($config_data,"config");


    }

    public function show_footer()
    {
      global $db;
      $fetch_data_sql  = "SELECT * FROM ".PREFIX."config"; 
      $result_fetch    = $db->fetch_single_row($fetch_data_sql);
      echo $f_footer   = $result_fetch['page_footer'];
    } 

    public function show_title()
    {
      global $db;
      $fetch_data_sql  = "SELECT * FROM ".PREFIX."config"; 
      $result_fetch    = $db->fetch_single_row($fetch_data_sql);
      echo $f_title    = $result_fetch['page_title'];
    } 


    public function redirect_page($location)

    {

      if (!headers_sent()) {

          header('Location: ' . $location);

      exit;

     } 
    
    else

          echo '<script type="text/javascript">';

          echo 'window.location.href="' . $location . '";';

          echo '</script>';

          echo '<noscript>';

          echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';

          echo '</noscript>';

   }
   
   public function send_mail($from, $to, $subject, $message )
          {
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            // More headers
            $headers .= 'From: <'.$from.'>' . "\r\n";
            //$headers .= 'Cc: myboss@example.com' . "\r\n";
            if (mail($to,$subject,$message,$headers))
               {
                 echo '
                    <div class="isa_success">
                        <i class="fa fa-check"></i>
                         <strong>Success</strong> Email has been sent successfully.
                         </div>
                         </div>
                         ';       
               }
            else
               {
                echo '
                    <div class="isa_error">
                         <strong>Error!</strong> Unable to send mail.
                         </div>
                         </div>
                         ';    
               }
          }

    public function cleanOut($text) {

       $text =  strtr($text, array('\r\n' => "", '\r' => "", '\n' => ""));

       $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');

       $text = str_replace('<br>', '<br />', $text);

       return stripslashes($text);

      }


    public function Smilify(&$subject)
        {
        $smilies = array(
        ':|'  => 'mellow',
        ':-|' => 'mellow',
        ':-o' => 'ohmy',
        ':-O' => 'ohmy',
        ':o'  => 'ohmy',
        ':O'  => 'ohmy',
        ';)'  => 'wink',
        ';-)' => 'wink',
        ':p'  => 'tongue',
        ':-p' => 'tongue',
        ':P'  => 'tongue',
        ':-P' => 'tongue',
        ':D'  => 'biggrin',
        ':-D' => 'biggrin',
        '8)'  => 'cool',
        '8-)' => 'cool',
        ':)'  => 'smile',
        ':-)' => 'smile',
        ':('  => 'sad',
        ':-(' => 'sad',
        );

        $sizes = array(
        'biggrin' => 18,
        'cool' => 20,
        'haha' => 20,
        'mellow' => 20,
        'ohmy' => 20,
        'sad' => 20,
        'smile' => 18,
        'tongue' => 20,
        'wink' => 20,
        );

        $replace = array();
        foreach ($smilies as $smiley => $imgName)
        {
        $size = $sizes[$imgName];
        array_push($replace, '<img src="images/'.$imgName.'.png" alt="'.$smiley.'" width="'.$size.'" height="'.$size.'" />');
        }
        return $subject = str_replace(array_keys($smilies), $replace, $subject);
        }

     
        /*Start Noor Global Academy Portion*/

        /**

       * Show Lecturtes

       */  

       public function show_lectures()
        {
          global $db,$user;
          $fetching_lectures = "SELECT * FROM ".PREFIX."lectures";
          $fetched_lectures = $db->fetch_all($fetching_lectures);
          foreach ($fetched_lectures as $key => $fetched_value) {
            $specific_portion = substr($fetched_value['lecture_iframe'], 0, strpos($fetched_value['lecture_iframe'], "<p>"));
            echo $specific_portion;
          }
        }

    

    /*Start staff records Portion*/

       /**

       * Show departments

       */  

    public function show_departments()
    {
      
     global $db;
     $dep_fetch_query = "SELECT sr_department.*, sr_users.first_name, sr_users.last_name FROM ".PREFIX."department LEFT JOIN sr_users ON sr_department.dep_head=sr_users.id order by sr_department.id"; 
     $res = $db->fetch_all($dep_fetch_query);
     $sr_no = 1;
     foreach ($res as $key => $value) {
        //echo implode(",", $value);
    
      echo 
      "<tr><td clas='hidden-phone'>".$sr_no++."</td>".
      "<td>".$value['department_name']."</td>".
      "<td>".$value['first_name']." ".$value['last_name']."</td>".

      '<td>
        <a class="js-open-modal" href="#" data-modal-id="popup_edit'.$value['id'].'"><img src="images/edit-icon.png"/></a>
        <a class="js-open-modal" href="#" data-modal-id="popup'.$value['id'].'"><img src="images/yellow-cross-icon.png"/></a>
       </td> 
       </tr>';
       }   
    }

    
       /**

       * Show projects

       */ 


    public function show_projects()
    {
      
     global $db,$user;
     $redirect_active   = SITEURL.'DRDH/manage_projects/';
     $redirect_edit     = SITEURL.'DRDH/create_project/';
     
     if ($user->is_login_admin())
        {
          $pro_fetch_query = "SELECT * FROM ".PREFIX."projects order by id";      
        }
     else
       {
        $pro_fetch_query = "SELECT * FROM ".PREFIX."projects WHERE department_of= ".$user->get_current_user()['department']." order by id";      
       } 
     
     $res = $db->fetch_all($pro_fetch_query);
     $sr_no = 1;
     foreach ($res as $key => $value) {
      if($value['status'] == 1){
        $active_status = 'Active';
      }
      else{
        $active_status = 'Inactive';
      }
      if($value['complete_status'] == 1){
        $complete_status = 'Completed';
      }
      else{
        $complete_status = 'Running';
      }
    
      echo 
      "<tr><td clas='hidden-phone'>".$sr_no++."</td>".
      "<td><a href='".SITEURL."DRDH/specific_project/?id=".base64_encode($value['id'])."'>".$value['project_name']."</a></td>".
      "<td>".$value['starting_date']."</td>".
      "<td>".$value['ending_date']."</td>".
      "<td>".$value['customer_details']."</td>".
      "<td>".$active_status."</td>".
      "<td>".$complete_status."</td>";
      if($value['complete_status'] == 1){
      echo 
         '<td>
         ____
         </td>
         ';
      }
      else{
      echo
      '<td>
        <a class="js-open-modal" href="'.$redirect_active.'?id='.$value['id'].'&action=active " ><img src="images/Button-Blank-Yellow-icon.png"/></a>
        <a class="js-open-modal" href="'.$redirect_edit.'?HFLsohf=89e6 &id='.base64_encode($value['id']).'"><img src="images/edit-icon.png"/></a>
        <a href="#" data-target="#popup'.$value['id'].'" data-toggle="modal"><img src="images/yellow-cross-icon.png"/></a>
        <a href="#" data-target="#popup_complete'.$value['id'].'" data-toggle="modal"><img src="images/done.png"/></a>
       </td>'; 
      }
      echo '</tr>';

       }   
    }

    

       /**

       * Show tasks

       */ 
    public function show_tasks()
    {
      
     global $db,$user;
     $task_fetch_query = "SELECT sr_tasks.id AS task_id, sr_tasks.* ,sr_projects.* 
     FROM sr_tasks 
     INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id 
     WHERE sr_projects.department_of = ".$user->get_current_user()['department']."  ORDER BY sr_projects.id";
     $res = $db->fetch_all($task_fetch_query);
     $sr_no = 1;
     foreach ($res as $key => $value) {
      if ($value['assignment'] == 0 )
          {
            $assignment = "Not yet assigned";
          } 
      else
         {
            $mafe = explode(",", $value['assignment']);
            /*
            $str = $value['assignment'];
            preg_match_all('!\d+!', $str, $matches);
            print_r($matches);
            */
            $max = count($mafe);
            $assignment = null;
            for ($i=0; $i < $max ; $i++) { 
                 $user_sql = "SELECT DISTINCT * FROM ".PREFIX."users WHERE id=".$mafe[$i];
                 $member_name = $db->fetch_single_row($user_sql);
                 $assignment.= $member_name['first_name']." ".$member_name['last_name'].",";
            }
         }
      echo 
      "<tr><td clas='hidden-phone'>".$sr_no++."</td>".
      "<td>".$value['task_title']." of "."<b style='color: green;'>".$value['project_name']."</b>".""."</td>".
      "<td>".$assignment."</td>".
      
      '<td>
        <a href="#" data-target="#popup_assign'.$value['task_id'].'" data-toggle="modal"><img src="images/briefcase-icon.png"/></a>
        <a class="" href="'.SITEURL.'DRDH/add_task/?id='.base64_encode($value['task_id']).'"><img src="images/edit-icon.png"/></a>
        <a href="#" data-target="#modal'.$value['task_id'].'" data-toggle="modal" ><img src="images/yellow-cross-icon.png"/></a>
       </td> 
       </tr>';
       
       //<a href="#" data-target="#modal" data-toggle="modal">
       }   
    }

       /**

       * Show todo list for team member

       */ 

       public function show_todo() 
       {
           global $db,$user,$custom_fun;
           $own_task = $user->get_current_user()['id'];
           $task_fetch_query = "SELECT sr_tasks.id AS task_id, sr_tasks.* ,sr_projects.* FROM sr_tasks INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id ";
           $res = $db->fetch_all($task_fetch_query);
          
          foreach ($res as $key => $value) {
          
            $mafe = explode(",", $value['assignment']);
            $max = count($mafe);
            $assignment = null;
            for ($i=0; $i < $max ; $i++) { 
                 $mafe[$i];
                 if ($mafe[$i] == $own_task)
                     {
                      $select_specific_task = "SELECT sr_tasks.id AS task_id, sr_tasks.* ,sr_projects.* FROM sr_tasks INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id WHERE sr_tasks.id=".$value['task_id'];//." AND sr_tasks.is_completed != ".$mafe[$i]."";
                      $fetched_inner_task = $db->fetch_all($select_specific_task);
                     foreach ($fetched_inner_task as $key => $task_value) {
                       $set = null;        
                      /*Checking is this task is mark as completed by the login user */
                      $check_complete_dup = explode(",", $task_value['is_completed']);
                      foreach ($check_complete_dup as $key => $value_mafe) {
                        if ($value_mafe == $user->get_current_user()['id'])  
                           {
                            $set = TRUE;
                            break;
                           }
                        }
                      
                        if ($set == TRUE)
                           {
                            break;
                           }
                           
                           $fetch_comment = "SELECT * FROM ".PREFIX."task_comments WHERE project_id = ".$value['concerned_project']." AND task_id=".$value['task_id']." AND user_id=".$user->get_current_user()['id']." ";
                           $comment = $db->fetch_single_row($fetch_comment);
                           
                           $var_ex_comment = $this->cleanOut($comment['task_comments']);
                           echo 
                            '<ul class="todo-list">
                              <li class="todo-list-item">
                                  <div class="checkbox">
                                    <input type="checkbox" id="checkbox" name="completed[]" value="'.$task_value['task_id'].'" />
                                    <label for="checkbox">'.$task_value['task_title']." of "."<b style='color: #0099cc;'>".$value['project_name']."</b>"."".'
                                    '.'<b style="color: red;">['.$task_value['task_timeline'].' Hours]</b>'.'<a class="js-open-modal" href="#" data-modal-id="popup_info'.$task_value['task_id'].'">&nbsp; <img src="images/gossip-birds-icon.png"></a>'.'
                                    
                                    <div style="width: 100%; margin-top: 10px; border: 3px solid; border-radius: 10px; padding: 5px 5px 5px 5px; border-color: #0099cc;" > <b>Details:</b>'.$task_value['description'].'</div>
                                    <div style="width: 100%; margin-top: 10px; border: 3px solid; border-radius: 10px; padding: 5px 5px 5px 5px; border-color: #0099cc;" > <b>Comments:</b>'.$this->smilify($var_ex_comment).'</div>  
                                    </label>
                                  </div>
                                  <!--
                                  <div class="pull-right action-buttons">
                                    
                                    <a class="js-open-modal" href="#" data-modal-id="popup_info'.$task_value['id'].'"><svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg></a>
                                    <a href="#" class="flag"><svg class="glyph stroked flag"><use xlink:href="#stroked-flag"></use></svg></a>
                                    <a href="#" class="trash"><svg class="glyph stroked trash"><use xlink:href="#stroked-trash"></use></svg></a>
                                  </div>
                                  -->      
                                </li>
                              </ul>';
                              //echo '<input type="hidden" name="main_task_id[]" value="'.$task_value['task_id'].'">'; 
                              } // Inner foreach
                     }
             }//End for 
            } //Main outter foreach
       }


       /**

       * Show project oriented tasks

       */  

 public function show_tasks_details()
    {
      
     global $db,$user;
     $task_fetch_query = "SELECT sr_tasks.id AS task_id, sr_tasks.* ,sr_projects.*, sr_projects.id AS project_id 
     FROM sr_tasks 
     INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id 
     WHERE assignment !='' AND sr_projects.department_of = ".$user->get_current_user()['department']." ORDER BY sr_projects.id ";
     $res = $db->fetch_all($task_fetch_query);
     $sr_no = 1;
     foreach ($res as $key => $value) {
      if ($value['is_completed'] == "" )
          {
            $is_completed = "Not yet mark.";
          } 
      else
         {
            $mafe = explode(",", $value['is_completed']);
            /*
            $str = $value['assignment'];
            preg_match_all('!\d+!', $str, $matches);
            print_r($matches);
            */
            $max = count($mafe);
            $is_completed = null;
            for ($i=0; $i < $max ; $i++) { 
                 $user_sql = "SELECT DISTINCT * FROM ".PREFIX."users WHERE id=".$mafe[$i];
                 $member_name = $db->fetch_single_row($user_sql);
                 $is_completed.= $member_name['first_name']." ".$member_name['last_name'].",";
            }
         }

            $name_asg = NULL;  
            $mul_asg = explode(",", $value['assignment']);
            $max_asg = count($mul_asg);
            for ($j=0; $j < $max_asg ; $j++) { 
                 $user_sql_asg = "SELECT DISTINCT first_name, last_name FROM ".PREFIX."users WHERE id=".$mul_asg[$j];
                 $member_name_asg = $db->fetch_single_row($user_sql_asg);
                 $name_asg.= $member_name_asg['first_name']." ".$member_name_asg['last_name'].",";
            }
      echo 
      "<td>".$value['task_title']." of "."<a href='".SITEURL."DRDH/specific_project/"."?id=".base64_encode($value['project_id'])."'><b style='color: green;'>".$value['project_name']."</b></a>".""."</td>".
      "<td>".$name_asg."</td>".
      "<td>".$is_completed."</td>"
      .'</tr>';
       }   
    }

       
       /**

       * Show tasks comments according to projects

       */  

 public function show_tasks_comments()
    {
      
     global $db,$user;
     //$task_fetch_query = "SELECT sr_tasks.id AS task_id, sr_tasks.* ,sr_projects.*, sr_projects.id AS project_id FROM sr_tasks INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id WHERE assignment !='' AND sr_projects.department_of = ".$user->get_current_user()['department']." ORDER BY sr_projects.id ";
     $fetch_task_comment = "SELECT * FROM ".PREFIX."task_comments ORDER BY comment_date DESC";
     $res = $db->fetch_all($fetch_task_comment);
     
     $sr_no = null;
     foreach ($res as $key => $value) {
      $sr_no++;
      /*
      $fetch_task_comment = "SELECT * FROM ".PREFIX."task_comments";
      $fetched_task_comment = $db->fetch_single_row($fetch_task_comment);
      */
      $user_sql = "SELECT first_name, last_name FROM ".PREFIX."users WHERE id=".$value['user_id'];
      $member_name = $db->fetch_single_row($user_sql);
      $user_name   = $member_name['first_name']." ".$member_name['last_name'];

      $fetch_project_task = "SELECT sr_projects.*, sr_tasks.* FROM ".PREFIX."projects 
      INNER JOIN sr_tasks ON sr_projects.id = sr_tasks.concerned_project WHERE sr_projects.id= ".$value['project_id']."";
      $fetched_project_task = $db->fetch_single_row($fetch_project_task);  
      $desired_cmt = $this->cleanOut($value['task_comments']);
      echo 
      '<tr>'.   
      '<td>'.$sr_no.'</td>'.
      '<td>'.$value['comment_date'].'</td>'
      ."<td>".$fetched_project_task['task_title']." of <b style='color: green;'>".$fetched_project_task['project_name']."</b>".""."</td>".
      "<td>".$user_name."</td>"
      ."<td>".$this->smilify($desired_cmt)."</td>"
      .'</tr>';
       }   
    }



       /**

       * Show All tasks with phases for a specific project

       */ 

       
       public function show_specific_project_tasks() 
       {
        global $db;
        echo '<div align="center">'; // Start of main div
        $fetch_data_sql = "SELECT sr_projects.*, sr_phases.*, sr_phases.id AS phase_id, sr_tasks.*, sr_users.* FROM sr_projects INNER JOIN sr_phases ON sr_phases.project_code = sr_projects.id INNER JOIN sr_tasks ON sr_tasks.concerned_phase = sr_phases.id INNER JOIN sr_users ON sr_tasks.is_completed = sr_users.id WHERE sr_projects.id = ".base64_decode($_GET['id'])." GROUP BY sr_phases.phase ";
        $org_result = $db->fetch_all($fetch_data_sql);
        $counter = null; 
        foreach ($org_result as $key => $value_data) {
            $counter++;
            if ($counter == 1)
               {
                echo '<h1>'.$value_data['project_name'].'</h1>';
                echo '<div align="left">';
                //echo '<b>Project Head:</b> Anam Ghulam Muhammad'.'<br>';
                echo '<b>Start Date:</b> '.$value_data['starting_date'].' '.'<br>';
                echo '<b>End Date:</b>   '.$value_data['ending_date'].' '.'<br>';
                echo '</div>'; 
                echo '<h4>Phase wise Details</h4>'.'<br>'.'<br>';
                echo '<div align="left">';
               }
            echo '<h3>'.$value_data['phase'].'</h3>'; 
            echo '<ul>';
            $fetching_tasks_users = "SELECT sr_tasks.id AS task_main_id, sr_tasks.* FROM sr_tasks INNER JOIN sr_phases ON sr_phases.id = sr_tasks.concerned_phase WHERE sr_tasks.concerned_project = ".base64_decode($_GET['id'])." AND sr_tasks.concerned_phase = ".$value_data['phase_id'] ;
            $fetched_mafe = $db->fetch_all($fetching_tasks_users);
            foreach ($fetched_mafe as $key => $value_mafe) {
                    $multi = explode(",", $value_mafe['is_completed']);
                    $max_it = count($multi);
                    
                    for ($cou=0; $cou < $max_it; $cou++) { 
                      $user_sql = "SELECT DISTINCT * FROM ".PREFIX."users WHERE id=".$multi[$cou];
                      $member_name = $db->fetch_single_row($user_sql);
                      echo  "<b style=''>".$member_name['first_name']." ".$member_name['last_name']."</b>";
                      echo '
                      <li>'.$value_mafe['task_title'].'</li>'; 
                    }
              
            }
            echo '</ul>';
            }
       echo '</div>';
       echo '</div>'; // End of main div
       }

        /**

       * Daily task Report of all team members Email

       */ 

       public function daily_task_mail() 
       {
        global $db,$user;
        $fetch_data_sql = "SELECT sr_projects.*, sr_phases.*, 
                           sr_phases.id AS phase_id, sr_tasks.*, 
                           sr_users.*, sr_complete_date.* 
                           FROM sr_projects 
                           INNER JOIN sr_phases        ON sr_phases.project_code = sr_projects.id 
                           INNER JOIN sr_tasks         ON sr_tasks.concerned_phase = sr_phases.id 
                           INNER JOIN sr_users         ON sr_tasks.is_completed = sr_users.id 
                           INNER JOIN sr_complete_date ON sr_tasks.id = sr_complete_date.task_id 
                           WHERE sr_complete_date.complete_date = '".date('Y-m-d')."' 
                           AND sr_projects.department_of = ".$user->get_current_user()['department']."
                            ";
        
        $org_result = $db->fetch_all($fetch_data_sql);
        $counter = null; 
        $dep_query =  'SELECT department_name FROM '.PREFIX.'department WHERE id= '.$user->get_current_user()['department'].'  '; 
        $dep_name  =  $db->fetch_single_row($dep_query)['department_name'];
        $mail_content = "<H4>".date('Y-m-d')." Tasks Details of ".$dep_name."</H4>";
        $mail_content.= "<table border='1'>";
        $mail_content.= "<th>No.</th><th>Person</th><th>Task</th>";
        foreach ($org_result as $key => $value_data) {
            $counter++;
            $fetching_tasks_users = "     SELECT sr_tasks.id AS task_main_id, sr_tasks.*, 
                                          sr_complete_date.*
                                          FROM sr_tasks 
                                          INNER JOIN sr_phases ON sr_phases.id = sr_tasks.concerned_phase
                                          INNER JOIN sr_complete_date ON sr_complete_date.task_id = sr_tasks.id 
                                          WHERE sr_tasks.concerned_project = ".$value_data['concerned_project'].
                                          " AND sr_complete_date.task_id = ".$value_data['task_id'].
                                          " GROUP BY sr_complete_date.user_id  " ;
            
            $fetched_mafe = $db->fetch_all($fetching_tasks_users);
            $count_mafe = null;
            foreach ($fetched_mafe as $key => $value_mafe) {
                    
                    $multi = explode(",", $value_mafe['is_completed']);
                    $max_it = count($multi);
                    for ($cou=0; $cou < $max_it; $cou++) { 
                      $count_mafe++;
                      if ($count_mafe == 1)
                         {
                          break;
                         }
                      $user_sql = "SELECT * FROM ".PREFIX."users WHERE id=".$multi[$cou]." GROUP BY id";
                      $member_name = $db->fetch_single_row($user_sql);
                      $mail_content.= "<tr><td>".$counter."</td><td>".$member_name['first_name']." ".$member_name['last_name']."&nbsp; </td>";
                      $mail_content.= "<td>".$value_mafe['task_title'].'&nbsp; of &nbsp;'."<b style='color: green;'>".$value_data['project_name']."</b>"."</td></tr>"; 
                    }
                 }
            }
       $mail_content.= "</table>";
       echo $mail_content;
       if ($_SERVER["REQUEST_METHOD"] == "POST")
           {
            $this->send_mail("e.connect.gulfam@gmail.com","e.connect.gulfam@gmail.com","Hello", $mail_content);
           }
       }
       
        /**

       * Task History of a specific Member

       */

       public function task_history_member()       
       {
        global $user,$db;

        if (isset($_POST['done_now']))
        {
        $view_query =
        'SELECT 
        sr_tasks.id AS TASK_MAIN,sr_tasks.task_title,sr_tasks.task_timeline, sr_tasks.concerned_project, sr_tasks.concerned_phase, sr_tasks.assignment,sr_tasks.is_completed, sr_tasks.description,
        sr_projects.id AS PROJECT_MAIN, sr_projects.project_name, sr_projects.department_of, sr_projects.starting_date, sr_projects.ending_date, sr_projects.customer_details, sr_projects.status, 
        sr_projects.comments, sr_phases.id AS PHASE_MAIN, sr_phases.project_code, sr_phases.phase,
        sr_complete_date.id AS MAIN_COMPLETE_DATE, sr_complete_date.user_id, sr_complete_date.task_id, sr_complete_date.complete_date,
        sr_users.id AS MAIN_USER, sr_users.first_name, sr_users.last_name
        FROM sr_tasks 
        INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id
        INNER JOIN sr_phases ON sr_projects.id = sr_phases.project_code 
        INNER JOIN sr_complete_date ON sr_tasks.id = sr_complete_date.task_id
        INNER JOIN sr_users ON sr_complete_date.user_id WHERE sr_complete_date.user_id = '.$user->get_current_user()['id'].' AND sr_complete_date.complete_date BETWEEN "'.$_POST['from_date'].'" AND "'.$_POST['to_date'].'" GROUP BY sr_complete_date.task_id';                          
        $all_rows = $db->fetch_all($view_query);

         
         //$fetching_sql = "";
         /*Start of Tables*/
         $counter = null;
         $task_contents =   
             '<table data-toggle="table" data-url="">
                <thead>
                <tr>
                    <th data-field="id" data-align="">Sr#</th>
                    <th data-field="name">Date</th>
                    <th data-field="price">Task Description</th>
                </tr>
                </thead>
                <tbody>';
                foreach ($all_rows as $key => $value_row) {
                if ($counter == 0)
                   {
                    $task_contents .= '<div style="margin-top: 50px;"><b>Tasks Details of '.$user->get_current_user()['first_name'].' '.$user->get_current_user()['last_name'].' From : '.$_POST['from_date'].' To: '.$_POST['to_date'].'</b></div>';
                   } 
                $counter++;
                $task_contents .='<tr><td>'.$counter.'</td><td>'.$value_row['complete_date'].'</td><td>'.$value_row['task_title'].' of '.'<strong>'.$value_row['project_name'].'</strong>'.' from the phase of '.'<strong>'.$value_row['phase'].'</strong>'.'<div> <strong>Task Details: </strong>'.$value_row['description'].'</div>'.'</td></tr>';    
                
                }
                
                
                $task_contents.= '</tbody>
                                  </table>';
                echo $task_contents;
          }
          /*End of Tables*/
       }

        /**

       * Daily team activities

       */

       public function daily_team_activities()       
       {
        global $user,$db;
        $view_query =
        'SELECT 
        sr_tasks.id AS TASK_MAIN,sr_tasks.task_title,sr_tasks.task_timeline, sr_tasks.concerned_project, sr_tasks.concerned_phase, sr_tasks.assignment,sr_tasks.is_completed, sr_tasks.description,
        sr_projects.id AS PROJECT_MAIN, sr_projects.project_name, sr_projects.department_of, sr_projects.starting_date, sr_projects.ending_date, sr_projects.customer_details, sr_projects.status, 
        sr_projects.comments, sr_phases.id AS PHASE_MAIN, sr_phases.project_code, sr_phases.phase,
        sr_users.id AS MAIN_USER, sr_users.first_name, sr_users.last_name,
        sr_task_comments.id AS MAIN_COMMENT, sr_task_comments.comment_date, sr_task_comments.project_id, sr_task_comments.task_id, sr_task_comments.user_id, sr_task_comments.task_comments
        FROM sr_tasks 
        INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id
        INNER JOIN sr_phases ON sr_projects.id = sr_phases.project_code 
        INNER JOIN sr_task_comments ON sr_task_comments.task_id = sr_tasks.id
        INNER JOIN sr_users ON sr_task_comments.user_id = sr_users.id 
        WHERE sr_users.department = '.$user->get_current_user()['department'].' 
        AND sr_task_comments.user_id = sr_users.id 
        AND sr_task_comments.comment_date = "'.date('Y-m-d').'"
        GROUP BY sr_users.id';                          
        $all_rows = $db->fetch_all($view_query);
        $mail_data = NULL;
        $mail_data .= '<table border="1">'; 
        foreach ($all_rows as $key => $value_all) {
        $mail_data .=   '<tr><td>'.$value_all['comment_date'].'</td><td>'.$value_all['first_name'].' '.$value_all['last_name'].'</td>
                 <td> 
                 <table>';
           
        $task_query =
        'SELECT 
        sr_tasks.id AS TASK_MAIN,sr_tasks.task_title,sr_tasks.task_timeline, sr_tasks.concerned_project, sr_tasks.concerned_phase, sr_tasks.assignment,sr_tasks.is_completed, sr_tasks.description,
        sr_projects.id AS PROJECT_MAIN, sr_projects.project_name, sr_projects.department_of, sr_projects.starting_date, sr_projects.ending_date, sr_projects.customer_details, sr_projects.status, 
        sr_projects.comments, sr_phases.id AS PHASE_MAIN, sr_phases.project_code, sr_phases.phase,
        sr_users.id AS MAIN_USER, sr_users.first_name, sr_users.last_name,
        sr_task_comments.id AS MAIN_COMMENT, sr_task_comments.comment_date, sr_task_comments.project_id, sr_task_comments.task_id AS cmnt_task, sr_task_comments.user_id AS cmnt_user, sr_task_comments.task_comments,
        sr_complete_date.id AS MAIN_COMPLETE_DATE, sr_complete_date.user_id AS comd_user, sr_complete_date.task_id AS comd_task, sr_complete_date.complete_date
        FROM sr_tasks 
        INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id
        INNER JOIN sr_phases ON sr_projects.id = sr_phases.project_code 
        INNER JOIN sr_task_comments ON sr_task_comments.task_id = sr_tasks.id
        INNER JOIN sr_users ON sr_task_comments.user_id = sr_users.id 
        LEFT JOIN  sr_complete_date ON sr_complete_date.task_id = sr_tasks.id
        WHERE sr_users.department = '.$user->get_current_user()['department'].' 
        AND sr_task_comments.comment_date = "'.date('Y-m-d').'"
        AND sr_task_comments.user_id      = '.$value_all['MAIN_USER'].'
        GROUP BY sr_tasks.id';      
        
        $all_tasks = $db->fetch_all($task_query);   
           foreach ($all_tasks as $key => $value_tasks) {
                if ($value_tasks['comment_date'] == $value_tasks['complete_date'] AND $value_tasks['cmnt_task'] == $value_tasks['comd_task'] AND $value_tasks['cmnt_user'] == $value_tasks['comd_user'] )
                    {
                      $place_status = "Completed";
                    }

                 if ($value_tasks['comment_date'] != $value_tasks['complete_date'] AND $value_tasks['cmnt_task'] != $value_tasks['comd_task'] AND $value_tasks['cmnt_user'] != $value_tasks['comd_user'] )
                    {
                      $place_status = "Continue";
                    }   
                $mail_data .= '<tr><td>'.$value_tasks['task_title'].' of <strong>'.$value_tasks['project_name'].'</strong> &nbsp;<strong>('.$place_status.')</strong><div width="100%" style="border: 1px solid; padding: 3px 3px 3px 3px;"><strong>Task Details: </strong>'.$value_tasks['description'].'</div></td></tr>';            
                }
           $mail_data .= '</table>
                          </td>
                          </tr>';
        
        }
        $mail_data .= '</table>';

        echo $mail_data;   
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
           {
            $this->send_mail("e.connect.gulfam@gmail.com","e.connect.gulfam@gmail.com","Hello", $mail_data);
           }
       }


       /**

       * Team activities according to date

       */

       public function team_activities_datewise()       
       {
        if ($_SERVER["REQUEST_METHOD"] == "POST")
         {
        global $user,$db;
        $view_query =
        'SELECT 
        sr_tasks.id AS TASK_MAIN,sr_tasks.task_title,sr_tasks.task_timeline, sr_tasks.concerned_project, sr_tasks.concerned_phase, sr_tasks.assignment,sr_tasks.is_completed, sr_tasks.description,
        sr_projects.id AS PROJECT_MAIN, sr_projects.project_name, sr_projects.department_of, sr_projects.starting_date, sr_projects.ending_date, sr_projects.customer_details, sr_projects.status, 
        sr_projects.comments, sr_phases.id AS PHASE_MAIN, sr_phases.project_code, sr_phases.phase,
        sr_users.id AS MAIN_USER, sr_users.first_name, sr_users.last_name,
        sr_task_comments.id AS MAIN_COMMENT, sr_task_comments.comment_date, sr_task_comments.project_id, sr_task_comments.task_id, sr_task_comments.user_id, sr_task_comments.task_comments
        FROM sr_tasks 
        INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id
        INNER JOIN sr_phases ON sr_projects.id = sr_phases.project_code 
        INNER JOIN sr_task_comments ON sr_task_comments.task_id = sr_tasks.id
        INNER JOIN sr_users ON sr_task_comments.user_id = sr_users.id 
        WHERE sr_users.department = '.$user->get_current_user()['department'].' 
        AND sr_task_comments.user_id = sr_users.id 
        AND sr_task_comments.comment_date = "'.$_POST['for_date'].'"
        GROUP BY sr_users.id';                          
        
        $all_rows = $db->fetch_all($view_query);
        $mail_data = NULL;
        $mail_data .= '<table border="1">'; 
        foreach ($all_rows as $key => $value_all) {
        $mail_data .=   '<tr><td>'.$value_all['comment_date'].'</td><td>'.$value_all['first_name'].' '.$value_all['last_name'].'</td>
                 <td> 
                 <table>';
           
        $task_query =
        'SELECT 
        sr_tasks.id AS TASK_MAIN,sr_tasks.task_title,sr_tasks.task_timeline, sr_tasks.concerned_project, sr_tasks.concerned_phase, sr_tasks.assignment,sr_tasks.is_completed, sr_tasks.description,
        sr_projects.id AS PROJECT_MAIN, sr_projects.project_name, sr_projects.department_of, sr_projects.starting_date, sr_projects.ending_date, sr_projects.customer_details, sr_projects.status, 
        sr_projects.comments, sr_phases.id AS PHASE_MAIN, sr_phases.project_code, sr_phases.phase,
        sr_users.id AS MAIN_USER, sr_users.first_name, sr_users.last_name,
        sr_task_comments.id AS MAIN_COMMENT, sr_task_comments.comment_date, sr_task_comments.project_id, sr_task_comments.task_id AS cmnt_task, sr_task_comments.user_id AS cmnt_user, sr_task_comments.task_comments,
        sr_complete_date.id AS MAIN_COMPLETE_DATE, sr_complete_date.user_id AS comd_user, sr_complete_date.task_id AS comd_task, sr_complete_date.complete_date
        FROM sr_tasks 
        INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id
        INNER JOIN sr_phases ON sr_projects.id = sr_phases.project_code 
        INNER JOIN sr_task_comments ON sr_task_comments.task_id = sr_tasks.id
        INNER JOIN sr_users ON sr_task_comments.user_id = sr_users.id 
        LEFT JOIN  sr_complete_date ON sr_complete_date.task_id = sr_tasks.id
        WHERE sr_users.department = '.$user->get_current_user()['department'].' 
        AND sr_task_comments.comment_date = "'.$_POST['for_date'].'"
        AND sr_task_comments.user_id      = '.$value_all['MAIN_USER'].'
        GROUP BY sr_tasks.id';      
        
        $all_tasks = $db->fetch_all($task_query);   
           foreach ($all_tasks as $key => $value_tasks) {
                if ($value_tasks['comment_date'] == $value_tasks['complete_date'] AND $value_tasks['cmnt_task'] == $value_tasks['comd_task'] AND $value_tasks['cmnt_user'] == $value_tasks['comd_user'] )
                    {
                      $place_status = "Completed";
                    }

                 if ($value_tasks['comment_date'] != $value_tasks['complete_date'] AND $value_tasks['cmnt_task'] != $value_tasks['comd_task'] AND $value_tasks['cmnt_user'] != $value_tasks['comd_user'] )
                    {
                      $place_status = "Continue";
                    }   
                $mail_data .= '<tr><td>'.$value_tasks['task_title'].' of <strong>'.$value_tasks['project_name'].'</strong> &nbsp;<strong>('.$place_status.')</strong><div width="100%" style="border: 1px solid; padding: 3px 3px 3px 3px;"><strong>Task Details: </strong>'.$value_tasks['description'].'</div></td></tr>';            
                }
           $mail_data .= '</table>
                          </td>
                          </tr>';
        
        }
        $mail_data .= '</table>';

        if ($db->number_rows_hide($task_query) < 1)
           {
            echo "<h3>Sorry No report for the day..!</h3>";
           }
        
        echo $mail_data;

        }   
        
        
       
       }


        /**

       * Tasks report member-wise

       */

       public function team_activities_memberwise()       
       {
        if ($_SERVER["REQUEST_METHOD"] == "POST")
         {
        global $user,$db;
        $mail_data = NULL; 
        $task_query =
        'SELECT 
        sr_tasks.id AS TASK_MAIN,sr_tasks.task_title,sr_tasks.task_timeline, sr_tasks.concerned_project, sr_tasks.concerned_phase, sr_tasks.assignment,sr_tasks.is_completed, sr_tasks.description,
        sr_projects.id AS PROJECT_MAIN, sr_projects.project_name, sr_projects.department_of, sr_projects.starting_date, sr_projects.ending_date, sr_projects.customer_details, sr_projects.status, 
        sr_projects.comments, sr_phases.id AS PHASE_MAIN, sr_phases.project_code, sr_phases.phase,
        sr_users.id AS MAIN_USER, sr_users.first_name, sr_users.last_name,
        sr_task_comments.id AS MAIN_COMMENT, sr_task_comments.comment_date, sr_task_comments.project_id, sr_task_comments.task_id AS cmnt_task, sr_task_comments.user_id AS cmnt_user, sr_task_comments.task_comments,
        sr_complete_date.id AS MAIN_COMPLETE_DATE, sr_complete_date.user_id AS comd_user, sr_complete_date.task_id AS comd_task, sr_complete_date.complete_date
        FROM sr_tasks 
        INNER JOIN sr_projects ON sr_tasks.concerned_project = sr_projects.id
        INNER JOIN sr_phases ON sr_projects.id = sr_phases.project_code 
        INNER JOIN sr_task_comments ON sr_task_comments.task_id = sr_tasks.id
        INNER JOIN sr_users ON sr_task_comments.user_id = sr_users.id 
        LEFT JOIN  sr_complete_date ON sr_complete_date.task_id = sr_tasks.id
        WHERE sr_users.department = '.$user->get_current_user()['department'].'
        AND sr_task_comments.user_id      = '.$_POST['user_id'].'
        AND sr_complete_date.user_id      ='. $_POST['user_id'].'    
        GROUP BY sr_tasks.id';      
        
        /*User Info*/
        $user_basic_sql =  "SELECT first_name, last_name FROM ".PREFIX."users WHERE id = ".$_POST['user_id'];
        $user_details   = $db->fetch_single_row($user_basic_sql);
        /*User Info*/
        $mail_data .= "<h4>Working details of ".$user_details['first_name']." ".$user_details['last_name']."</h4>";
        $mail_data .= '<table border="0">';
        $all_tasks = $db->fetch_all($task_query);   
           foreach ($all_tasks as $key => $value_tasks) {
                if ($value_tasks['comment_date'] == $value_tasks['complete_date'] AND $value_tasks['cmnt_task'] == $value_tasks['comd_task'] AND $value_tasks['cmnt_user'] == $value_tasks['comd_user'] )
                    {
                      $place_status = "Completed";
                    }

                 //if ($value_tasks['comment_date'] != $value_tasks['complete_date'] AND $value_tasks['cmnt_task'] != $value_tasks['comd_task'] AND $value_tasks['cmnt_user'] != $value_tasks['comd_user'] )
                    else
                    {
                      $place_status = "Continue";
                    }   
                $mail_data .= '<tr><td>'.$value_tasks['task_title'].' of <strong>'.$value_tasks['project_name'].'</strong> &nbsp;<strong>('.$place_status.')</strong><div width="100%" style="border: 1px solid; padding: 3px 3px 3px 3px;"><strong>Task Details: </strong>'.$value_tasks['description'].'</div></td></tr>';            
                }
           $mail_data .= '</table>';
        
        if ($db->number_rows_hide($task_query) < 1)
           {
            echo "<h3>No Work found..!</h3>";
           }
        
        echo $mail_data;

        }   
        
       }


        /**

       * Show # of tasks to do for member (User)

       */

        public function show_taks_total()
        {
                global $db, $user;
                $fetch_sql         = "SELECT id, assignment, is_completed FROM ".PREFIX."tasks";
                $fetch_rest_tasks  = $db->fetch_all($fetch_sql);  
                $todo_tasks = 0;
                foreach ($fetch_rest_tasks as $key => $uc_tasks) {
                  $indexes_assignment = array();
                  $indexes_completed  = array();
                  $indexes_assignment = NULL;
                  $indexes_completed  = NULL;
                  //$todo_tasks         = NULL;
                  
                  $multi_assignemt = explode(",", $uc_tasks['assignment']);
                  $multi_completed = explode(",", $uc_tasks['is_completed']);
                  $max_assignment  = count($multi_assignemt);
                  $max_completed   = count($multi_completed);
                  
                  for ($i=0; $i < $max_assignment ; $i++) { 
                    $indexes_assignment[] = $multi_assignemt[$i];
                  }
                  
                  for ($j=0; $j < $max_completed ; $j++) { 
                    $indexes_completed[] = $multi_completed[$j]; 
                  }
                    asort($indexes_assignment);
                    asort($indexes_completed);
                    $final = array_combine($indexes_assignment, $indexes_completed);
                    foreach ($final as $key => $fetched_final) {
                      if ($key == $fetched_final)
                         {
                              if ($user->get_current_user()['id'] == $key AND  $user->get_current_user()['id'] == $fetched_final)
                                 { 
                                  #echo "Completed<br>";
                                 }
                         }
                      else
                         {
                           if ($user->get_current_user()['id'] != $fetched_final AND $user->get_current_user()['id'] == $key)
                                 { 
                                  #echo "Assigned but Not completed<br>";
                                  $todo_tasks++;
                                 }
                         }
                    }
                 }  
         echo $todo_tasks;
        }

        /**

       * Show # of tasks comments (User)

       */

        public function show_total_comments()
        {
          global $db, $user;
          $fetch_comments_sql = "SELECT id FROM ".PREFIX."task_comments WHERE comment_date='".date('Y-m-d')."' AND user_id=".$user->get_current_user()['id']." ";
          $db->number_rows($fetch_comments_sql);  
        }

        /**

       * Show # of completed tasks (User)

       */

        public function show_total_completed()
        {
          global $db, $user;
          $fetch_completed_sql = "SELECT id FROM ".PREFIX."complete_date WHERE complete_date='".date('Y-m-d')."' AND user_id=".$user->get_current_user()['id']." ";
          $db->number_rows($fetch_completed_sql);  
        }

        /**

       * Show # of daily total tasks (HOD)

       */

        public function show_hod_assigned_tasks()
        {
          global $db, $user;
          $fetch_assigned_sql = "SELECT id FROM ".PREFIX."assign_date WHERE assign_date='".date('Y-m-d')."' ";
          $db->number_rows($fetch_assigned_sql);  
        }

        /**

       * Show # of daily tasks comments (HOD)

       */

        public function show_comments_tasks()
        {
          global $db, $user;
          $fetch_all_comments_sql = "SELECT id FROM ".PREFIX."task_comments WHERE comment_date='".date('Y-m-d')."' ";
          $db->number_rows($fetch_all_comments_sql);  
        }

       /**

       * Show # of daily completed tasks (HOD)

       */

        public function show_completed_tasks()
        {
          global $db, $user;
          $fetch_all_completed_sql = "SELECT id FROM ".PREFIX."complete_date WHERE complete_date='".date('Y-m-d')."' ";
          $db->number_rows($fetch_all_completed_sql);  
        }

        /**

       * Show # of all running projects (HOD)

       */

        public function show_all_projects()
        {
          global $db, $user;
          $fetch_all_projects_sql = "SELECT id FROM ".PREFIX."projects ";
          $db->number_rows($fetch_all_projects_sql);  
        }



} //End Class
?>