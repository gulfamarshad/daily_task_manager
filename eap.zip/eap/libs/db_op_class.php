<?php

  /**

   * Database operations class

   * @author Gulfam Khan

   * @copyright 2016

   */


class db_op {
public $run="";

public function db_connect($db_name, $user_name, $password, $sel_db)     
                         {
                          $con =  mysql_connect($db_name, $user_name, $password) or die('<p style="font-size: 50px;">Database Connection Error</p> ' . mysql_error());
                          mysql_select_db($sel_db,$con) or die('<p style="font-size: 50px;">Database Connection Error</p> ' . mysql_error());;

                         } 

    public function run_query($query)
                {
                  $this->run = mysql_query($query);
                  return $this->run;
                }  



       public function fetch_all($org_query)
                        {
                            $pera = $this->run_query($org_query); // Call another function of same calls.
                            $count_len=mysql_num_rows($pera);
                            //$org_val = mysql_fetch_array($pera);
                           $records = array();
                           
                           while ($org_val = mysql_fetch_array($pera, MYSQL_ASSOC) )
                                    {

                                    //echo implode("_",$org_val)."<br>";
                                    $records[] = $org_val;
                                    
                                    }
                                  
                            return $records;
                            
                        }
      
      public function fetch_single_row($original_query)
                      {
                        $ret_res = $this->run_query($original_query);
                        $org_val_single = mysql_fetch_array($ret_res, MYSQL_ASSOC);
                        return $org_val_single;

                      }


      public function insert_values($data,$tbl)
                      {
                          $columns = implode(", ",array_keys($data));
                          $escaped_values = array_map('mysql_real_escape_string', array_values($data));
                          $values  = implode("', '", $escaped_values);
                          $sql = "INSERT INTO ".PREFIX.$tbl."(".$columns.")"."VALUES('".$values."')";
                          $check_run = $this->run_query($sql);
                          if ($check_run)
                                         {
                                           echo '
                                           <div id="s_msg" style="width:100%;" align="center">
                   
                                           <div class="alert alert-success">
                                           <strong>Success!</strong> Data has been Inserted Successfully.
                                           </div>
                                           </div>
                                                 ';
                                         }
                          else
                                           {
                                          echo '
                                           <div id="s_msg" style="width:100%;" align="center">
                   
                                           <div class="alert alert-error">
                                           <strong>Error!</strong> Something went wrong! Unable to Insert data.
                                           </div>
                                           </div>
                                                 ';  
                                           }
                      } 
          public function insert_new_lead($data,$tbl)
                      {
                          $columns = implode(", ",array_keys($data));
                          $escaped_values = array_map('mysql_real_escape_string', array_values($data));
                          $values  = implode("', '", $escaped_values);
                          $sql = "INSERT INTO ".PREFIX.$tbl."(".$columns.")"."VALUES('".$values."')";
                          $check_run = $this->run_query($sql);
                         
                      }                               

          public function number_rows($un_query)
                      {
                        $un_query_res = $this->run_query($un_query);
                        $out_un_query_res = mysql_num_rows($un_query_res);
                        echo $out_un_query_res;
                      }

          public function number_rows_hide($un_query)
                      {
                        $un_query;
                        $un_query_res = $this->run_query($un_query);
                        $out_un_query_res = mysql_num_rows($un_query_res);
                        return $out_un_query_res;
                      }            
      
          public function update_values($data,$tbl,$conti=null)
                      {
                        $counter = 0;
                      
                        foreach ($data as $key => $value) {
                                           $counter ++;
                                          if ($counter == "1")
                                           {
                                            $update_query = $update_query = "UPDATE ".PREFIX.$tbl." SET ";
                                           }
                                           $update_query.= $key."="."'".$value."'".',';
                                         } ;  
                                        if (isset($_GET['id']))
                                          {
                                          $final_SQL = rtrim($update_query, ',')." WHERE id=".base64_decode($_GET['id']);    
                                          }

                                        if (!isset($_GET['id']))  
                                          {
                                            $final_SQL = rtrim($update_query, ',')." WHERE id=".$conti;
                                          }
                                         //echo $final_SQL;

                                        if ($this->run_query($final_SQL) )
                                        {
                                          echo '
                                           <div id="s_msg" style="width:100%;" align="center">
                   
                                           <div class="alert alert-success">
                                           <strong>Success!</strong> Data has been updated Successfully.
                                           </div>
                                           </div>
                                                 ';
                                        }

                                        else
                                           {
                                         echo '
                                           <div id="s_msg" style="width:100%;" align="center">
                   
                                           <div class="alert alert-error">
                                           <strong>Error!</strong> Something went wrong! Unable to update data.
                                           </div>
                                           </div>
                                                 ';  
                                           }
                                         

                      }


} //End class


?>